/*:#localized(key: "TheTask")
 # The task

 One task, stated plainly, that shows up in every app:

 **Fetch two independent pieces of data, combine them, handle errors, and
 deliver the result on the main thread.**

 At the corner coffee bar, that's: fetch today's **menu** (the drinks we plan to
 offer) and today's **stock** (how many of each we actually have). Then combine
 them into the list we can really sell: a drink is sellable only if it's on the
 menu *and* in stock. Two fetches that don't depend on each other, so they
 should run **in parallel**. (either can fail). And the final list updates the
 UI, so it has to land on the main thread.

 We'll solve it **Version A** (classic) and **Version B** (modern). Read both, then
 compare.

 [Previous](@previous)  |  page 2 of 8  |  [Next: Version A: The Classic Way](@next)
 */
