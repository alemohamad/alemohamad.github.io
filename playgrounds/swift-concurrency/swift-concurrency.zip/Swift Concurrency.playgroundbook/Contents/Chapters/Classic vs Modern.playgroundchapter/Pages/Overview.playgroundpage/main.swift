/*:#localized(key: "Overview")
 # Classic vs. Modern

 You've now met both toolkits end to end. The classic model gave you queues,
 groups, semaphores, and operations; the modern model gave you `async`/`await`,
 tasks, actors, and `@MainActor`.
 
 So here's the honest question a working iOS developer asks: *when I sit down
 to write real code, which one do I reach for, and what do I do about the pile
 of GCD already in my app?*
 
 This chapter answers that by taking one ordinary task and solving it both
 ways, side by side, then mapping every classic idea onto its modern
 replacement and laying out a migration plan you can actually follow on
 Monday.

 ---
 
 ## What you'll learn

 * The **same real task** solved twice, classic (GCD + completion handlers +
 `DispatchGroup`) and modern (`async`/`await` + `async let`), so you can feel the
 difference in readability, error handling, and sheer line count.
 * A **concept map** from each classic tool to its modern counterpart.
 * **When the classic model is still the right call**, honestly.
 * A **pragmatic migration strategy** for an existing GCD codebase.
 * A small **"which tool when"** cheat sheet to keep.

 Turn to the next page to meet the task we'll solve both ways.

 page 1 of 8  |  [Next: The Task](@next)
 */
