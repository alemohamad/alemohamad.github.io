/*:#localized(key: "WhichToolWhen")
 # Which tool when: a cheat sheet

 Keep this nearby. In new code, start from the **Modern** column; drop to the
 **Classic** column only for a listed reason.

 * **Run work off the main thread.**  
 Modern: `Task { }`. Classic: `queue.async`.
 * **Run two or three independent fetches, known up front.**  
 Modern: `async let`. Classic: `DispatchGroup`.
 * **Run a variable number of parallel jobs.**  
 Modern: `TaskGroup`. Classic: group + semaphore.
 * **Protect shared mutable state.**  
 Modern: `actor`. Classic: serial queue or count-1 semaphore.
 * **Touch the UI / return to main.**  
 Modern: `@MainActor`. Classic: `DispatchQueue.main.async`.
 * **Handle a stream of events over time.**  
 Modern: `AsyncStream`. Classic: delegate or repeating callback.
 * **Bridge one existing callback API.**  
 Modern: `withCheckedContinuation`. Classic: *this is how you cross over*.
 * **Cancel in-flight work.**  
 Modern: cooperative `Task` cancellation. Classic: `Operation.cancel()` +
 manual `isCancelled`.

 ---

 One case runs the other way: when you genuinely need a **specific queue, QoS,
 timer source, or barrier**, GCD is still the right, direct tool, and there's
 no modern replacement to reach for.

 [Previous](@previous)  |  page 7 of 8  |  [Next: Wrapping Up](@next)
 */
