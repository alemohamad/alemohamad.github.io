/*:#localized(key: "MarkingFunctionOrProperty")
 # You can mark just a function or a property

 `@MainActor` isn't all-or-nothing. You can tag a single function, a single
 stored property, or a whole type. A common pattern: a background-friendly type
 with one main-actor method that publishes results.
 */
//#-editable-code
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

struct Statement {
    let lines: [String]

    // Only this function is pinned to the main thread.
    @MainActor
    func present() {
        for line in lines {
            print("STATEMENT: \(line)")
        }
    }
}

let statement = Statement(lines: ["Opening balance: 100", "Deposit: 50", "Closing balance: 150"])

Task {
    await statement.present()
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "MarkingFunctionOrPropertyNotice")
 Callers of `present()` from off-main will need `await`; the rest of `Statement`
 stays free to run anywhere.

 [Previous](@previous)  |  page 5 of 11  |  [Next: Defining Your Own Global Actor](@next)
 */
