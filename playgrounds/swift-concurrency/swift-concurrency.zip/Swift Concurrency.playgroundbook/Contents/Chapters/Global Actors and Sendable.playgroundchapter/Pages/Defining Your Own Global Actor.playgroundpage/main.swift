/*:#localized(key: "CustomGlobalActor")
 # Defining your own global actor

 `MainActor` is the built-in one, but you can declare your own. Use
 `@globalActor` when you have a domain (a cache, a log, an on-disk ledger) that
 many types should share **one serialized access lane** to, no matter where they
 live in your code.

 A global actor is just a type with a `shared` actor instance:
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

@globalActor
actor LedgerActor {
    static let shared = LedgerActor()
}
//#-end-editable-code
/*:#localized(key: "CustomGlobalActorUsage")
 Now tag anything that belongs to the ledger's domain with `@LedgerActor`. Every
 tagged function and property is serialized through that single actor; calls
 from elsewhere hop onto it with `await`, just like `@MainActor`:
 */
//#-editable-code
@LedgerActor
func record(_ entry: String) {
    print("Ledger recorded: \(entry)")
}

@LedgerActor
func auditCount(_ entries: [String]) -> Int {
    entries.count
}

Task {
    await record("Opened account #4471")
    await record("Deposit 100")
    let n = await auditCount(["a", "b", "c"])
    print("Audit saw \(n) entries")
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "CustomGlobalActorNotice")
 Because `record` and `auditCount` share `@LedgerActor`, Swift guarantees they
 never run at the same time as each other, even if two unrelated tasks call them
 at once. You've drawn a safety boundary around a *concept*, not a single object.
 Reach for this rarely (most code wants either an ordinary actor or
 `@MainActor`), but it's the right tool when a whole subsystem must be
 single-lane.

 [Previous](@previous)  |  page 6 of 11  |  [Next: Sendable](@next)
 */
