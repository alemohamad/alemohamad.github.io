/*:#localized(key: "Overview")
 # Global Actors and Sendable

 Back in the classic chapters you learned the golden rule: **UI work happens on the
 main thread.** The classic way to honor it was to wrap every UI update in
 `DispatchQueue.main.async { ... }` and *hope* you never forgot. Forgetting was a
 silent bug: the app usually looked fine, then glitched under load. The modern
 model does something better: it lets you *mark* code as "main thread only" and
 has the **compiler** check every call for you. That marker is `@MainActor`, and
 it's one member of a bigger idea, **global actors**, that pairs with a protocol
 called **`Sendable`** to let Swift prove your concurrency is safe before you ever
 run it. That proof is what this chapter is about.

 ---
 
 ## What you'll learn

 * What `@MainActor` is, and how it replaces "hop back to `DispatchQueue.main`."
 * How to define your own **global actor** with `@globalActor`.
 * What **`Sendable`** means, and why a mutable class isn't Sendable.
 * What `@Sendable` closures restrict, and why `Task` requires them.
 * How Swift 6 turns all of this into **compile-time** data-race checking.

 Turn the page and we'll start with `@MainActor`, the marker you'll reach for
 constantly.

 page 1 of 11  |  [Next: MainActor and the Main Thread](@next)
 */
