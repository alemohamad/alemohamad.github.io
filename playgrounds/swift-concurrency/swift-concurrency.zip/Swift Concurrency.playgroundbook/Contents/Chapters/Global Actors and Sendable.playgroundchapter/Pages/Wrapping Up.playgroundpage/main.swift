/*:#localized(key: "WrappingUp")
 # Wrapping up

 This chapter is two halves of one promise: global actors like `@MainActor` pin
 code to a single serialized domain, and `Sendable` marks which values may cross
 between domains. Together they let the Swift 6 compiler turn data races into
 compile errors before you ever run. The takeaways below hinge on resisting two
 opposite shortcuts that quietly switch that protection off.

 * **`@MainActor`** guarantees code runs on the main thread and is
 compiler-checked: the modern replacement for `DispatchQueue.main.async`.
 Calling it (or any actor-isolated code) from another domain needs **`await`**.
 To reach the main actor on purpose, hop one closure with **`MainActor.run { }`**
 or run a whole task there with **`Task { @MainActor in }`**; once you're on the
 main actor, those `await` hops disappear.
 * Isolate only what genuinely touches shared UI state; draping everything in
 `@MainActor` drags background-friendly work onto the main thread and
 reintroduces the freezes from the chapter [Why Concurrency](Why%20Concurrency.playgroundchapter/Overview).
 * **`@globalActor`** lets you define your own single-serialized-domain marker
 for a whole subsystem; use it sparingly.
 * **`Sendable`** marks types safe to cross concurrency boundaries. Value types
 and immutable final classes qualify; **a class with any `var` does not**, no
 matter how careful your usage: fix it by making an actor, making it immutable,
 or isolating it. Reach for `@unchecked Sendable` only for types that truly
 manage their own locking, never to silence an error.
 * **`@Sendable`** closures (like the one `Task` takes) may only capture
 Sendable values and can't mutate captured `var`s.
 * Swift 6 uses all of this to turn data races into **compile-time errors**:
 treat those errors as the compiler proving your concurrency safe.

 ---
 
 ## Up next

 **[Classic vs. modern](Classic%20vs%20Modern.playgroundchapter/Overview)**: the same problem solved both ways, so you can see
 the whole arc at once and decide when to migrate.

 [Previous](@previous)  |  page 11 of 11
 */
