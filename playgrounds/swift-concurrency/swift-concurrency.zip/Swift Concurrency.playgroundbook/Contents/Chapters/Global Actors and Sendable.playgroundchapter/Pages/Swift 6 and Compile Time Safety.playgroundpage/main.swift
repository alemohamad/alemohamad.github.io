/*:#localized(key: "Swift6CompileTimeSafety")
 # Swift 6: the compiler proving your concurrency is safe

 Step back and see the machine you've been building. `Sendable` says *which
 values can cross a boundary*. Actor isolation (`@MainActor`, your own global
 actors, plain actors) says *which domain a piece of code belongs to*. Put
 together, they let the Swift 6 compiler trace every boundary crossing in your
 program and prove that no two domains ever touch the same mutable state at the
 same time. When it can't prove it, you get a **compile error instead of a data
 race**.

 That's a genuinely new deal. In the classic model, a race was something you
 diagnosed *after* it bit you: intermittent, hard to reproduce, invisible in a
 code review. With this machinery, the same mistake usually can't reach `Run`.
 The annotations you've learned here aren't bureaucracy; they're you handing the
 compiler enough information to do the checking for you.

 So when you meet a Sendable or isolation error, don't read it as the compiler
 being difficult. Read it as: *"I found a place two pieces of code could
 collide: tell me which domain this belongs to."* Answer that question and the
 error clears. The errors are on your side.

 [Previous](@previous)  |  page 10 of 11  |  [Next: Wrapping Up](@next)
 */
