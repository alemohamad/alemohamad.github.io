/*:#localized(key: "ThreeQueues")
 # The three queues you'll use

 There are exactly three sources of queues you need to know.

 **1. The main queue**: `DispatchQueue.main`.  
 Work here runs on the **main thread**, the one that owns your UI. This is
 where you come back to update labels, reload a list, or start an
 animation.

 **2. Global queues**: `DispatchQueue.global()`.  
 These are shared, system-provided background queues. Reach for one whenever
 you have work that shouldn't be on the main thread and you don't need a
 queue of your own.

 **3. Custom queues**: `DispatchQueue(label: "...")`.  
 A queue you create and name. The label shows up in debuggers and crash logs,
 so give it a clear reverse-DNS-style name. Custom queues are **serial by
 default**, which makes them a simple tool for protecting shared state (more
 on that in the chapter [Concurrency Hazards](Concurrency%20Hazards.playgroundchapter/Overview)).
 */
//#-editable-code
import Foundation

let main = DispatchQueue.main
let global = DispatchQueue.global()
let orders = DispatchQueue(label: "coffee-bar.orders")

print("main:   \(main.label)")
print("global: \(global.label)")
print("custom: \(orders.label)")
//#-end-editable-code
/*:#localized(key: "ThreeQueues-2")
 **Watch it run:** you'll see three labels. The main and global queues already
 exist; you're just getting a handle to them. The custom queue is one you
 named yourself. Nothing ran on a background thread yet; you only *described*
 the queues.

 [Previous](@previous)  |  page 2 of 9  |  [Next: async: Schedule It and Move On](@next)
 */
