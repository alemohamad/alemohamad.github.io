/*:#localized(key: "Overview")
 # GCD Fundamentals

 ![Grand Central Dispatch](Grandcentralicon.png)

 In the chapter [Why Concurrency](Why%20Concurrency.playgroundchapter/Overview) you felt the problem: heavy work on the main thread freezes the
 app. Now you need the tool that moves work *off* it. Back at the corner coffee
 bar, imagine the manager stops assigning baristas by hand and instead installs
 an **order rail**: you clip a ticket to the rail and walk away; whichever
 barista is free grabs the next ticket. You never think about baristas, only
 about tickets and which rail they go on. That order rail is **Grand Central
 Dispatch**, and this chapter is how to use it.

 ---
 
 ## What you'll learn

 * What **Grand Central Dispatch (GCD)** is, and why you hand it closures
 instead of creating threads yourself.
 * The three kinds of **dispatch queue** (main, global, and custom) and when to
 reach for each.
 * **Serial vs. concurrent** queues: what each one guarantees about order and
 overlap.
 * The critical difference between **`async`** ("schedule it and move on") and
 **`sync`** ("block until it's done").
 * The canonical pattern: do work on a background queue, then **hop back to
 main** to touch the UI.
 * **Quality of Service (QoS)**: how you tell GCD how urgent a job is.

 ---
 
 ## What GCD actually is

 **Grand Central Dispatch** is a system library that manages a pool of
 background threads for you. Instead of creating and juggling threads
 yourself, which is error-prone and easy to overdo, you package work as a
 **closure** and hand it to a **queue**. GCD decides which thread runs it, and
 reuses a small pool of threads efficiently across your whole app.

 That inversion is the whole point. You stop asking *"which thread should
 this run on?"* and start asking *"which queue should this go on, and does
 order matter?"* You think about tickets and rails; GCD manages the baristas.

 A **dispatch queue** is a line of closures waiting to run. You add work to
 the back; GCD takes work from the front and runs it on a thread it manages.
 Everything in this chapter is a variation on that one idea.

 Next, meet the three queues you'll actually use.

 page 1 of 9  |  [Next: The Three Queues You'll Use](@next)
 */
