/*:#localized(key: "QualityOfService")
 # Quality of Service: how urgent is this?

 When you send work to a background queue, GCD wants to know *how important*
 it is, so it can schedule threads and battery wisely. You tell it with a
 **Quality of Service (QoS)**, a priority label on the work. Higher QoS gets
 more resources sooner; lower QoS is gentler on the battery and yields to
 more urgent work.

 There are four you'll actually use, from highest to lowest:

 1. **`.userInteractive`**: work the user is *watching happen right now*:
 animations, responding to a touch, keeping the interface smooth. Must feel
 instant. Keep it tiny. (This is effectively the priority of the main thread
 itself.)
 2. **`.userInitiated`**: the user asked for something and is waiting for the
 result: opening a document they tapped, loading the screen they navigated
 to. Aim for a second or two.
 3. **`.utility`**: longer work with visible progress that the user isn't
 staring at: a download with a progress bar, importing data. Seconds to
 minutes. GCD balances it for energy efficiency.
 4. **`.background`**: work the user isn't aware of at all: pre-fetching,
 tidying up, syncing. Can take a long time; the system runs it when
 convenient and throttles it to save power.

 Picking is mostly common sense: **is someone waiting on this, and are they
 watching? The more yes, the higher the QoS.** When in doubt, `.utility` for
 real background jobs and `.userInitiated` for "the user tapped and expects a
 result."
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// Two jobs at very different priorities, started at the same moment.
DispatchQueue.global(qos: .background).async {
    print("🧹 Low-priority cleanup starting")
    for _ in 1...3 {
        Thread.sleep(forTimeInterval: 0.1)
        print("   ...tidying")
    }
    print("🧹 Cleanup done")
}

DispatchQueue.global(qos: .userInitiated).async {
    print("📄 High-priority: loading the order the user tapped")
    Thread.sleep(forTimeInterval: 0.15)
    print("📄 Order loaded")
}

DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "QualityOfService-2")
 **Watch it run:** both jobs make progress. QoS is a *hint about priority*,
 not a strict "finish this before that." You'll typically see the
 high-priority order load promptly while the low-priority cleanup interleaves
 around it. On a busy device the gap would be more pronounced: `.background`
 work yields to anything more urgent.

 [Previous](@previous)  |  page 7 of 9  |  [Next: asyncAfter: Do It Later](@next)
 */
