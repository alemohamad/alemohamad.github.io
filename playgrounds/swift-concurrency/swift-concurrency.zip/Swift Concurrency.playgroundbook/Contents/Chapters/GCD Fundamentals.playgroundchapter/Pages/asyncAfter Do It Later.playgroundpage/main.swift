/*:#localized(key: "AsyncAfter")
 # `asyncAfter`: do it later

 Sometimes you want work to run *after a delay*: dismiss a banner in three
 seconds, retry after a pause. **`asyncAfter`** schedules a closure to run on
 a queue once a deadline passes.
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

print("Order placed. We'll call your name shortly...")

DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
    print("🔔 Order up! (1.5 seconds later)")
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "AsyncAfter-2")
 **Watch it run:** the first line prints immediately; the bell rings about a
 second and a half later. The `.now() + 1.5` is a **deadline**, not a promise
 of exact timing; the block runs at the *earliest* after the deadline, once
 the queue is free. It's for "not before now + delay," not precise
 scheduling.

 * callout(Try it): Change `.now() + 1.5` to `.now() + 0.3`: the bell rings
 sooner, but the first line still prints before it.

 [Previous](@previous)  |  page 8 of 9  |  [Next: Wrapping Up](@next)
 */
