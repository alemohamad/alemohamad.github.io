/*:#localized(key: "CompletionBlockBriefly")
 # `completionBlock`, briefly

 You've been using it already. Every `Operation` has a `completionBlock`: a closure
 the operation runs **once it reaches finished**, no matter how it got there. It
 looks like this:

 `operation.completionBlock = { print("This runs after the operation finishes") }`

 It's handy for reacting to a single operation's result. Two cautions: it runs on
 *some* thread (not guaranteed to be the main thread; hop back to the main queue
 before touching UI), and it fires for cancelled operations too, so check
 `isCancelled` inside if the difference matters.

 Every example so far has already shown `completionBlock` at work.

 [Previous](@previous)  |  page 6 of 7  |  [Next: Wrapping Up](@next)
 */
