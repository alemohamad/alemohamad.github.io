/*:#localized(key: "Overview")
 # Operation Dependencies and Cancellation

 Back at the small print shop from the chapter [Operations](Operations.playgroundchapter/Overview), a brochure is never one job. First
 someone **designs** the layout, then the press **prints** it, then the finishing
 table **binds** the pages into a booklet. Print before the design is ready and you
 waste paper; bind before the ink is dry and you get a mess. The order isn't a
 nice-to-have; it's the whole job. In this chapter you'll make `Operation`s run in
 the right order, stop them politely when a customer changes their mind, and handle
 the tricky case where an operation's work finishes *later*, in a callback.

 ---
 
 ## What you'll learn

 * How `addDependency(_:)` forces one operation to wait for another.
 * How to pass the output of one operation into the next.
 * The **cooperative** cancellation model: `cancel()` is a *request*, not a kill.
 * Why a plain `Operation` "finishes" too early for callback-based work, and how to
 build an **asynchronous operation** with a real state machine.
 * What `completionBlock` is for.

 When you're ready, turn the page and we'll put dependencies to work ordering a
 real pipeline.

 page 1 of 7  |  [Next: Ordering Work with Dependencies](@next)
 */
