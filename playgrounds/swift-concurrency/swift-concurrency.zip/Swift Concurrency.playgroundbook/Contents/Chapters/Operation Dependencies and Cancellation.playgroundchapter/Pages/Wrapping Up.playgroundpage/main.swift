/*:#localized(key: "WrappingUp")
 # Wrapping up

 Dependencies buy you correct ordering and race-free data hand-off between
 operations; cancellation and callback-driven work are where the manual bookkeeping
 stacks up. Nearly every pitfall below is a step you have to remember by hand:
 check the cancel flag, reach **finished** on every path, guard against a cancelled
 dependency. Notice how much there is to remember, because that bookkeeping is
 *exactly* what modern Swift concurrency automates, and the modern model is where
 you finally set it down.

 * `addDependency(_:)` forces ordering: a dependent won't start until all its
 dependencies report `isFinished`, but it orders work, it doesn't move data. Wire
 the output forward yourself, and guard for a **cancelled dependency** (still
 "finished", possibly with a `nil` output) before using it.
 * Because a dependency fully separates two operations in time, passing data from one
 to the next is race-free. Keep dependencies flowing one direction: a cycle leaves
 both operations forever un-*ready*.
 * Cancellation is **cooperative**: `cancel()` only sets `isCancelled`. Your `main()`
 must check the flag before slow steps and inside loops, and return early, or
 nothing stops.
 * A plain `Operation` is "finished" the instant `main()` returns, wrong for work
 that completes in a later callback.
 * An **asynchronous operation** overrides `isAsynchronous`, drives the
 `ready → executing → finished` state machine by hand, and fires KVO notifications
 so the queue notices. It must reach **finished** on every path, cancel included,
 or the queue stalls behind it, and capture `[weak self]` in the callback.
 * `completionBlock` runs once an operation finishes, on some thread, and even for
 cancelled operations.

 ---
 
 ## Up next

 The next chapter, [Why Modern Concurrency](Why%20Modern%20Concurrency.playgroundchapter/Overview),
 shows why modern concurrency exists: the callback problem
 laid bare, and what structured concurrency fixes about everything you just built by
 hand.

 [Previous](@previous)  |  page 7 of 7
 */
