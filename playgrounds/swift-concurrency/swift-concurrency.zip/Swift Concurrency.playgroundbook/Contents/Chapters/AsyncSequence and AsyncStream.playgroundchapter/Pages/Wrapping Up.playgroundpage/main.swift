/*:#localized(key: "AsyncSeqWrappingUp")
 # Wrapping up

 An async sequence is the tool for values that arrive *over time*, consumed with a
 `for await` loop that suspends between them instead of blocking. The recurring
 danger is a stream that never ends, or never cleans up after itself. Keep the
 lifecycle points below in view and streams stay well-behaved.

 * An **async sequence** delivers values *over time*; loop it with `for await` inside
 a `Task`, which suspends between elements instead of blocking. On a plain array, a
 normal `for` loop is correct and clearer.
 * **`AsyncStream`** turns a callback/timer/event source into an async sequence:
 `continuation.yield(_:)` emits, `continuation.finish()` ends it, and pitfall:
 without that `finish()` (or an error, or cancellation) the consumer's loop never
 stops.
 * **`onTermination`** runs once when the stream ends, normally or early, so it's
 where you cancel timers and release resources; skip it and a background producer
 leaks.
 * **Cancelling the consuming task** (or `break`ing out) stops consumption at the
 next suspension; awaiting the next value *is* the cancellation check.
 * **`AsyncThrowingStream`** adds failure: end with `finish(throwing:)` and consume
 with `for try await` inside `do-try-catch`.
 * This is the modern replacement for repeated-delegate and multi-callback patterns.

 ---
 
 ## Up next

 **[Continuations](Continuations.playgroundchapter/Overview)**: how to bridge a *single* old-style callback API into one clean
 `await`, the missing piece next to `AsyncStream`.

 [Previous](@previous)  |  page 7 of 7
 */
