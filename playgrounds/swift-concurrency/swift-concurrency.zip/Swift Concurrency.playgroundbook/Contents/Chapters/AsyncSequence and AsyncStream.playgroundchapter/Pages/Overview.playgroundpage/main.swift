/*:#localized(key: "Overview")
 # AsyncSequence and AsyncStream

 Time to leave the coffee bar for a new corner of our world: a **rooftop weather
 station**. Its temperature sensor doesn't hand you every reading at once. It emits
 one now, another a third of a second later, another after that: a trickle of
 values that arrives *over time*. A plain array can't model that: an array is all
 its elements, right now. What you want is something you can loop over like an array,
 except each turn of the loop politely waits for the next reading to show up. That's
 an **async sequence**, and this chapter is about consuming them and building your
 own.

 ---
 
 ## What you'll learn

 * What an **async sequence** is: a series of values that arrive over time.
 * How `for await value in sequence` loops over one, suspending between values.
 * How to **produce** a sequence from timers, callbacks, or events with `AsyncStream`.
 * How to clean up with `onTermination`, and how cancellation stops consumption.
 * When a stream can fail, and how `AsyncThrowingStream` + `for try await` handle it.

 page 1 of 7  |  [Next: A Sequence Whose Values Arrive Over Time](@next)
 */
