/*:#localized(key: "Overview")
 # Operations

 At a busy print shop, a rush of posters comes in. With GCD you'd hand each one
 to a queue as a closure and forget about it, great when the work is simple and
 you never need to touch it again. But a real job has a *name*, a *count of
 copies*, a *result*, and sometimes you want to hold onto it, inspect it, reuse
 its recipe, or later say "cancel that one." A closure has none of that. This
 chapter introduces **`Operation`**: a way to package work as a real object you
 can configure, name, and keep.

 ---
 
 ## What you'll learn

 * What an **`Operation`** is, and why "work as an object" beats a bare closure.
 * Using **`BlockOperation`** for quick cases, and the difference between running
 one with `.start()` and adding it to a queue.
 * Driving operations with an **`OperationQueue`**, and setting
 **`maxConcurrentOperationCount`**, including `1` to make a serial queue.
 * **Subclassing `Operation`**: overriding `main()` and storing inputs and outputs
 as properties.
 * When Operations fit and when plain GCD is the better tool.

 When you're ready, turn the page and we'll start by looking at what an operation 
 gives you that a closure doesn't.

 page 1 of 9  |  [Next: Work as an Object](@next)
 */
