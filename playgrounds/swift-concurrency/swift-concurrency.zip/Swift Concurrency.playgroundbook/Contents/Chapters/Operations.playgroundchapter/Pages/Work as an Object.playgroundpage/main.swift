/*:#localized(key: "WorkAsAnObject")
 # Work as an object, not just a closure

 In the chapter [GCD Fundamentals](GCD%20Fundamentals.playgroundchapter/Overview) you moved work off the main thread by handing a closure to a
 dispatch queue. That's perfect for **fire-and-forget** work: you dispatch it and
 never need to refer to it again.

 An **`Operation`** is a single unit of work wrapped in an object. Because it's an
 object, it can carry things a closure can't:

 * a **name** and stored **state** (inputs and outputs as properties),
 * the ability to be **cancelled** after you've created it,
 * **dependencies**: "don't start binding until printing finishes."

 Those last two, cancellation and dependencies, are where Operations really earn
 their keep, and they're the whole of the next chapter. This chapter builds the
 foundation: creating operations, running them, and queueing them.

 * callout(Heads-up): `Operation` and `OperationQueue` are built *on top of* GCD.
 You're not choosing a different engine; you're choosing a higher-level,
 object-shaped way to describe work.

 [Previous](@previous)  |  page 2 of 9  |  [Next: BlockOperation The Quick Case](@next)
 */
