/*:#localized(key: "BlockOperationTheQuickCase")
 # BlockOperation: the quick case

 The fastest way to make an operation is **`BlockOperation`**: an operation that
 just runs a closure you give it. It's the bridge from the GCD style you already
 know.
 */
//#-editable-code
import Foundation

let printFlyer = BlockOperation {
    print("Printing the flyer...")
}

printFlyer.start()
print("Flyer done, back on the main line")
//#-end-editable-code
/*:#localized(key: "BlockOperationTheQuickCase-2")
 **Watch it run:** you'll see `Printing the flyer...` and *then* `Flyer done...`, in
 that order, every time. That's the key surprise: **calling `.start()` runs the
 operation synchronously, right now, on the current thread.** Here that's the main
 thread, so nothing moved off it: `start()` didn't return until the block
 finished.

 So `.start()` by itself gives you *no* concurrency. It's useful for running an
 operation immediately and inline. To get work off the main thread, you hand the
 operation to a **queue** instead.

 * callout(Try it): A single `BlockOperation` can hold more than one block: add a
 second block with `printFlyer.addExecutionBlock { print("...") }` before
 `.start()`. Do both lines still finish before `Flyer done...`?

 [Previous](@previous)  |  page 3 of 9  |  [Next: OperationQueue Running in the Background](@next)
 */
