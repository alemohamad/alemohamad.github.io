/*:#localized(key: "OperationsVsGCD")
 # Operations vs. GCD: which to reach for

 Both move work off the main thread. Here's how to choose:

 * **Reach for GCD** when the work is a simple, one-shot closure: dispatch it and
 move on. Less ceremony, less code.
 * **Reach for an `Operation`** when you want the work as a *thing*: something
 with a name and state, something reusable, something you might need to
 **cancel**, or something that must run **after** other work finishes.

 That last pair, cancellation and dependencies, is the real reason Operations
 exist, and plain closures simply can't express them. You've now built every
 piece you need to use them, which is exactly where the next chapter goes.

 [Previous](@previous)  |  page 8 of 9  |  [Next: Wrapping Up](@next)
 */
