/*:#localized(key: "OperationQueueRunningInTheBackground")
 # OperationQueue: where operations actually run

 An **`OperationQueue`** accepts operations and runs them for you on background
 threads, managing the threads itself. You add work; the queue decides when and
 where it runs.
 */
//#-editable-code
import Foundation

let queue = OperationQueue()

for jobNumber in 1...4 {
    queue.addOperation {
        Thread.sleep(forTimeInterval: 0.1)   // pretend each job takes a moment
        print("Finished job \(jobNumber)")
    }
}

queue.waitUntilAllOperationsAreFinished()
print("All four jobs done")
//#-end-editable-code
/*:#localized(key: "OperationQueueRunningInTheBackground-2")
 `addOperation` takes a closure and wraps it in a `BlockOperation` for you.
 `waitUntilAllOperationsAreFinished()` blocks the calling thread until the queue
 empties, handy here so the page stays alive long enough to see the output.

 > In a real app you would *not* block a thread like this; you'd
 > use a completion or a dependency, which is the next chapter.

 **Watch it run:** the four `Finished job N` lines can appear in **any order**
 (you might see `1, 2, 4, 3`) and only then `All four jobs done`. By default a
 queue runs several operations **concurrently**, so they race to finish. Run it a
 few times; the order will shift. Never assume it.

 [Previous](@previous)  |  page 4 of 9  |  [Next: Making a Queue Serial](@next)
 */
