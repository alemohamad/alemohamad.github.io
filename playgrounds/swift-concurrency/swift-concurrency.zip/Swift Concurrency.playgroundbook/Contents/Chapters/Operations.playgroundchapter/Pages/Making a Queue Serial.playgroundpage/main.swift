/*:#localized(key: "MakingAQueueSerial")
 # Making a queue serial with maxConcurrentOperationCount

 Sometimes concurrency is exactly what you *don't* want. A single physical
 printer can only print one poster at a time. **`maxConcurrentOperationCount`**
 caps how many operations a queue runs at once. Set it to `1` and the queue
 becomes **serial**: one operation fully finishes before the next begins, in the
 order you added them.
 */
//#-editable-code
import Foundation

let printer = OperationQueue()
printer.maxConcurrentOperationCount = 1   // one job at a time

for jobNumber in 1...4 {
    printer.addOperation {
        print("Printing job \(jobNumber)")
    }
}

printer.waitUntilAllOperationsAreFinished()
print("The printer worked through the queue in order")
//#-end-editable-code
/*:#localized(key: "MakingAQueueSerial-2")
 **Watch it run:** now the output is **deterministic**: `Printing job 1`, then
 `2`, `3`, `4`, then the final line. With a limit of `1`, the jobs can't overlap,
 so they run strictly in FIFO order.

 * callout(Try it): Change `maxConcurrentOperationCount` to `2` and run it a few
 times. Does the output still come out strictly `1, 2, 3, 4` every time?

 > The default value is `-1`, written
 > `OperationQueue.defaultMaxConcurrentOperationCount`, which means "let the system
 > decide"; that's the concurrent behavior from the previous page. Any positive
 > number sets a ceiling; `1` is the special case that gives you a serial queue.

 [Previous](@previous)  |  page 5 of 9  |  [Next: Subclassing Operation](@next)
 */
