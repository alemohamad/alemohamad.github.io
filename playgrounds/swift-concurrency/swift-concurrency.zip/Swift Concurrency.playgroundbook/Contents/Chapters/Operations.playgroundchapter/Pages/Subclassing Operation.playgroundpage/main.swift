/*:#localized(key: "SubclassingOperation")
 # Subclassing Operation: work with inputs and outputs

 `BlockOperation` is convenient, but its whole job lives inside one closure. The
 real power of Operations shows up when you make your **own** subclass, because
 then the operation can hold **inputs** and expose **outputs** as properties, and
 you can reuse it like any other type.

 You subclass `Operation` and override one method: **`main()`**. Whatever
 `main()` does *is* the work. For this chapter we keep it **synchronous**:
 `main()` runs top to bottom and the operation is finished the moment `main()`
 returns.

 Here's a `PosterJob` for the print shop. It takes a title and a copy count as
 inputs, and produces a rendered poster string as its output.
 */
//#-editable-code
import Foundation

final class PosterJob: Operation {
    // Inputs: set when you create the job.
    let title: String
    let copies: Int

    // Output: filled in when the job runs.
    var renderedPoster: String?

    init(title: String, copies: Int) {
        self.title = title
        self.copies = copies
    }

    override func main() {
        // Pretend this is the "rendering" work.
        let banner = String(repeating: "*", count: title.count)
        renderedPoster = "\(banner)\n\(title) x\(copies)\n\(banner)"
    }
}

let job = PosterJob(title: "Jazz Night", copies: 50)
job.start()   // runs main() synchronously, right here
print(job.renderedPoster ?? "nothing rendered")
//#-end-editable-code
/*:#localized(key: "SubclassingOperation-2")
 **Watch it run:** after `start()` returns, `main()` has already run, so
 `renderedPoster` holds the result: a line of asterisks, then `Jazz Night x50`,
 then another line of asterisks.

 Notice the shape: **inputs go in through `init`, the work happens in `main()`,
 and the result comes out through a property.** That's a reusable, inspectable
 unit of work, something a bare closure can't give you.

 * callout(Try it): Add `print(Thread.isMainThread)` as the first line of
 `main()`. With this direct `.start()` call, does it report `true` or `false`?

 [Previous](@previous)  |  page 6 of 9  |  [Next: Running Your Subclass on a Queue](@next)
 */
