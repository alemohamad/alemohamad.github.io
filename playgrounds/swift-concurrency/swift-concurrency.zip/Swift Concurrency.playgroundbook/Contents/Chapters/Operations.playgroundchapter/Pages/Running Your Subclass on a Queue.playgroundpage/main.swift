/*:#localized(key: "RunningYourSubclassOnAQueue")
 # Running your subclass on a queue

 Because `PosterJob` is a real `Operation`, you can queue up a batch and let the
 queue run them in the background, then read each result once they're done.
 */
//#-hidden-code
import Foundation

// PosterJob, from the previous page: an Operation with inputs and an output.
final class PosterJob: Operation {
    let title: String
    let copies: Int
    var renderedPoster: String?

    init(title: String, copies: Int) {
        self.title = title
        self.copies = copies
    }

    override func main() {
        let banner = String(repeating: "*", count: title.count)
        renderedPoster = "\(banner)\n\(title) x\(copies)\n\(banner)"
    }
}
//#-end-hidden-code
//#-editable-code
let shop = OperationQueue()
shop.maxConcurrentOperationCount = 2   // two "printers" running at once

let jobs = [
    PosterJob(title: "Jazz Night", copies: 50),
    PosterJob(title: "Farmers Market", copies: 120),
    PosterJob(title: "Book Club", copies: 30),
]

shop.addOperations(jobs, waitUntilFinished: true)

for job in jobs {
    print(job.renderedPoster ?? "-")
    print("---")
}
//#-end-editable-code
/*:#localized(key: "RunningYourSubclassOnAQueue-2")
 `addOperations(_:waitUntilFinished:)` adds the whole array at once; passing
 `true` blocks until every one has finished, so it's safe to read the outputs
 right after. Each job carries its own inputs in and its own output back out,
 even though up to two of them run at the same time on background threads.

 **Watch it run:** all three rendered posters print. The jobs may have *run* in
 any order (two at a time), but because you read `jobs` in array order, the
 printed results appear in the order you created them. The *result* order and the
 *execution* order are two different things: keep them separate in your head.

 [Previous](@previous)  |  page 7 of 9  |  [Next: Operations vs GCD](@next)
 */
