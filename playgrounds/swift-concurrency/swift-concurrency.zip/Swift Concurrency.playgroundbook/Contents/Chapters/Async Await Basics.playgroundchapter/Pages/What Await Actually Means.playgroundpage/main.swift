/*:#localized(key: "WhatAwaitActuallyMeans")
 # What `await` actually means

 Here's the mental model to lock in. An `await` marks a **suspension point**:
 a place where the function *may* pause, hand the thread back to the system
 to do other work, and then resume on some thread later once its result is
 ready.

 > **This is the opposite of blocking.** In the chapter [Why Concurrency](Why%20Concurrency.playgroundchapter/Overview) you
 > made the main thread freeze with a big loop and `Thread.sleep`; that thread
 > sat there, useless, unable to draw or respond. `await` does *not* do that.
 > When an async function suspends, the thread is **freed** to run other work
 > (redraw the UI, serve another order). Your function is paused; the thread is
 > not stuck. When the awaited work finishes, your function is resumed. Same
 > waiting, no frozen thread.

 Notice the word **may**. `await` is a *possible* suspension point, not a
 guaranteed one. If the result happens to be ready immediately, the function
 might not pause at all. Either way, you write the same straight-line code.

 Keep this suspend-don't-block picture in mind as you turn the page.

 [Previous](@previous)  |  page 3 of 8  |  [Next: Tasks Aren't Threads](@next)
 */
