/*:#localized(key: "AwaitingInsideAnAsyncContext")
 # You can only `await` inside an async context

 There's one rule that trips up everyone at first: **`await` is only allowed
 inside an async context**: an `async` function, or a `Task { }`. You can't
 sprinkle `await` into ordinary top-level or synchronous code.

 That's why every example wraps its calls in `Task { }`, exactly as you first
 saw in the chapter [Introduction](Introduction.playgroundchapter/Running%20Modern%20Model). A **`Task`** is the bridge from the normal, synchronous
 world into async code:
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

func warmMug() async -> String {
    try? await Task.sleep(for: .milliseconds(400))
    return "🍵 Mug warmed"
}

// This top-level code is synchronous, no `await` allowed directly here.
Task {
    // ...but inside the Task, we're in an async context.
    let mug = await warmMug()
    print(mug)
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "AwaitingInsideAnAsyncContext-2")
 Try deleting the `Task { }` wrapper and calling `await warmMug()` at the top
 level: Swift refuses to compile it, because there's no async context for the
 `await` to live in. For now, "wrap it in a `Task`" is all you need. The full
 story of what a `Task` is, and how to cancel one, is in the chapter [Tasks and Cancellation](Tasks%20and%20Cancellation.playgroundchapter/Overview).

 [Previous](@previous)  |  page 5 of 8  |  [Next: Errors: Async Throws and Try Await](@next)
 */
