/*:#localized(key: "Overview")
 # Async Await Basics

 Back at the coffee bar, imagine ordering a latte and being handed a claim
 ticket: "we'll shout your name when it's ready." That's a **completion
 handler**: the callback style from the chapter [Why Modern Concurrency](Why%20Modern%20Concurrency.playgroundchapter/Overview). It works, but the code that
 waits for the shout gets tangled: nested closures, error handling bolted on
 the side, and no way to just read the order top to bottom. This chapter
 introduces `async`/`await`, which lets you write waiting code that reads like
 an ordinary recipe, one line after another, while *not* freezing the barista.

 ---
 
 ## What you'll learn

 * How to **define** an `async` function and **call** it with `await`.
 * What `await` really means: a **suspension point**, not a block.
 * Why a task is **not** a thread, and how a few threads run thousands of
 tasks.
 * How to reach async code from ordinary synchronous code with `Task { }`.
 * How `async throws` + `try await` turns error handling back into plain
 `do-try-catch`.
 * How to run independent work **concurrently** with `async let`, and see the
 total time shrink.

 Turn to the next page and define your first `async` function.

 page 1 of 8  |  [Next](@next)
 */
