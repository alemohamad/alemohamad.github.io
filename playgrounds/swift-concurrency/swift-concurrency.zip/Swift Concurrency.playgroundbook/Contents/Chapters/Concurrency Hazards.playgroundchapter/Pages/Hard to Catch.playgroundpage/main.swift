/*:#localized(key: "HardToCatch")
 # Why it's so hard to catch

 The corruption depends on *timing*: which teller happens to read during
 another's gap. Timing shifts with CPU load, core count, what else the device is
 doing, and plain luck. That's what **nondeterministic** means: the same code,
 same inputs, different results. So the bug:

 * **Might not reproduce.** It passed your tests because your tests got lucky.
 * **Might vanish under a debugger,** which changes the timing.
 * **Might only bite in production,** on a busier or slower device than yours.

 You cannot rely on running it to find it. You find it by *reading* for it. The
 one question that matters:

 **Is there state that is shared between concurrent tasks, and mutated, without
 anything coordinating the access?**

 In the example: `account.balance` is shared (one `Account`, captured by every
 closure), it's mutated (`account.balance = updated`), and nothing coordinates
 the concurrent `tellers` queue. Three for three: that's a data race, provable
 on paper, no test run required.

 * callout(Aside): In a full Xcode project there's a tool called the **Thread
 Sanitizer** that flags data races at runtime. It's Xcode-only, you won't have
 it in Swift Playground, so throughout this book you learn to reason races out
 by hand, which is the more durable skill anyway.

 [Previous](@previous)  |  page 3 of 9  |  [Next: The Serial Queue Fix](@next)
 */
