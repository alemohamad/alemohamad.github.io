/*:#localized(key: "PriorityInversion")
 # Priority inversion, briefly

 Back in the chapter [GCD Fundamentals](GCD%20Fundamentals.playgroundchapter/Overview) you met **Quality of Service (QoS)**: the priority hint
 (`.userInteractive`, `.utility`, `.background`, ...) that tells the system how
 urgent a queue's work is.

 **Priority inversion** is when a high-priority task is stuck waiting on a
 resource that a low-priority task is holding, so the "important" work is
 effectively running at the "unimportant" work's speed. Imagine a
 `.background` teller grabs the ledger lock, then gets starved of CPU time
 because the system is busy with other things. A `.userInteractive` teller now
 needs that same lock and can't have it. The urgent task waits on the lazy
 one. The priorities are *inverted*.

 You don't usually fix this by hand: GCD and the modern runtime perform
 **priority donation**, temporarily boosting the low-priority holder so it can
 finish and release the resource. What you *can* do to avoid trouble: don't
 share a single lock or serial queue across wildly different QoS levels, and
 keep the work inside any critical section short, so no one holds a shared
 resource longer than they must.

 [Previous](@previous)  |  page 7 of 9  |  [Next: Reasoning About Thread Safety](@next)
 */
