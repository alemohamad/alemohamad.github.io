/*:#localized(key: "ResponsivenessFirst")
 # Responsiveness first, speed second

 New concurrency learners often assume the goal is "make it faster." Sometimes.
 But the deeper, more constant goal is **responsiveness**: keep the main thread free
 so the interface never freezes. Moving a network call off the main thread doesn't
 make the network faster; it makes your app *feel alive* while the network takes its
 time.

 Two flavors of "slow" work you'll move off the main thread:

 * **I/O-bound waiting**: network requests, reading files, database queries. The
 CPU is mostly idle; you're waiting on something else. Concurrency shines here even
 with one core.
 * **CPU-bound work**: decoding an image, crunching numbers, applying a filter. The
 CPU is genuinely busy. Here you want a *background* thread so the main thread stays
 free, and parallelism (multiple cores) can make it finish sooner too.

 It's the idea to carry forward: you reach for
 concurrency first to stay responsive, and only second to go faster.

 [Previous](@previous)  |  page 4 of 5  |  [Next: Wrapping Up](@next)
 */
