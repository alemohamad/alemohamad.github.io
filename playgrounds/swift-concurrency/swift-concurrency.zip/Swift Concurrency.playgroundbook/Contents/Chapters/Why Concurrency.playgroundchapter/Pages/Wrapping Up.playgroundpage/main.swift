/*:#localized(key: "WrappingUp")
 # Wrapping up

 One fact drives this whole chapter: your app has a single **main thread**, and
 the user's experience lives or dies by whether you keep it free. Concurrency
 exists to structure work so tasks make progress independently instead of queueing
 behind that one thread. Keep the distinctions below in mind and the rest of the
 book follows naturally.

 * Your app has one **main thread**, and all UI runs on it; block it and the app
 freezes.
 * **Concurrency** structures work so tasks progress independently; **parallelism**
 runs them at the same instant on multiple cores.
 * Concurrency helps even on one core, because most slow work is *waiting*.
 * The first goal is **responsiveness** (free the main thread); speed is a secondary,
 parallelism-driven bonus.
 * **Pitfall:** heavy, non-instant work doesn't belong on the main thread, and UI
 updates must always return to it.
 * **Pitfall:** concurrent tasks finish in whatever order they finish. Never rely on
 completion order unless you deliberately enforce it.

 ---
 
 ## Up next

 The next chapter, [GCD Fundamentals](GCD%20Fundamentals.playgroundchapter/Overview),
 introduces Grand Central Dispatch: dispatch queues, `sync` vs.
 `async`, and quality of service, the actual tool for moving work off the main
 thread.

 [Previous](@previous)  |  page 5 of 5
 */
