/*:#localized(key: "MainThread")
 # Threads, and the one that matters most

 A **thread** is a single sequence of instructions the processor executes, one
 after another. Your app starts life with one thread already running: the **main
 thread**. It's special for one reason: **all your UI work must happen on it.**
 Drawing, touch handling, animations, updating a label: main thread, always.

 That gives the main thread a second job beyond running your code: it drives the
 **run loop** that keeps the interface alive, redrawing the screen many times a
 second. If you hand the main thread a long chunk of work, it can't redraw. To the
 user, the app has **frozen**.

 Let's feel it. The code below blocks the main thread on purpose:
 */
//#-editable-code
import Foundation

print("Tap accepted: starting a long task")

// Pretend this is heavy work: summing a huge range.
var total = 0
for number in 1...500_000 {
    total += number
}

print("Done. total = \(total)")
print("Only now could the UI respond again")
//#-end-editable-code
/*:#localized(key: "MainThread-2")
 **Watch it run:** the page pauses, then prints everything at once. In a real app,
 during that pause, scrolling would jam and taps would be ignored. Nothing is
 *broken*: the main thread is simply busy counting and can't do anything else. That
 is the entire problem concurrency exists to solve.

 * callout(Try it): Shrink the range to `1...1_000` and run again. Does the page
 still pause before it prints?

 [Previous](@previous)  |  page 2 of 5  |  [Next: Concurrency vs. Parallelism](@next)
 */
