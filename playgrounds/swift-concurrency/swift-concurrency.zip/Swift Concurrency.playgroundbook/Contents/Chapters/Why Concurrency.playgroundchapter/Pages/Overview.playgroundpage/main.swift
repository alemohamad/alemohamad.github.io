/*:#localized(key: "Overview")
 # Why Concurrency

 Picture a corner coffee bar. One barista takes an
 order, then walks to the roaster, grinds beans, waits for a slow pour-over, and
 only *then* turns to the next customer. The line backs up to the door, not because
 the barista is slow, but because they **block** on every wait. Your app's main
 thread is that single barista. This chapter is about why you can't let it stand
 around waiting.

 ---
 
 ## What you'll learn

 * What a **thread** is, and why the **main thread** is special.
 * The difference between **concurrency** and **parallelism**.
 * What "blocking the main thread" looks and feels like to a user.
 * Why concurrency is a tool for *responsiveness*, not just raw speed.

 When you're ready, turn to the next page and
 we'll make the problem tangible by freezing the main thread on purpose.

 page 1 of 5  |  [Next: The Main Thread](@next)
 */
