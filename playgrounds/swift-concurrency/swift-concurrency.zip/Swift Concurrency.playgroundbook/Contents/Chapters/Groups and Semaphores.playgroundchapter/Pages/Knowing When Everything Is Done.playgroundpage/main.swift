/*:#localized(key: "KnowingWhenEverythingIsDone")
 # The problem: knowing when everything is done

 Here's the batch, fired off the naïve way. Run it and watch what goes wrong.
 */
//#-editable-code
import Foundation

let barista = DispatchQueue(label: "barista", attributes: .concurrent)
let brewTimes = ["Latte": 0.8, "Cold brew": 0.3, "Espresso": 0.5]

for (drink, seconds) in brewTimes {
    barista.async {
        Thread.sleep(forTimeInterval: seconds)
        print("✅ \(drink) ready")
    }
}

print("🧾 Hand the tray to the customer")   // fires way too early
Thread.sleep(forTimeInterval: 1.0)          // keep the page alive to see it
//#-end-editable-code
/*:#localized(key: "KnowingWhenEverythingIsDone-2")
 **Watch it run:** `🧾 Hand the tray...` prints *first*, before a single drink is
 ready. The three `async` calls return immediately, they schedule the work and
 move on, so your "done" line runs while the drinks are still brewing. You need a
 way to say "run this line only once **all** the brewing has finished." That's a
 dispatch group, coming up next.

 * callout(Try it): Set every brew time to `0.1`. Does `🧾 Hand the tray...` still
 print before the drinks are ready?

 [Previous](@previous)  |  page 2 of 8  |  [Next: DispatchGroup: A Finish Line for Many Tasks](@next)
 */
