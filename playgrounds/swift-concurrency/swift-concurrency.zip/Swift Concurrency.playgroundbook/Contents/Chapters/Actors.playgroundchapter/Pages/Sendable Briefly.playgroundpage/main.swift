/*:#localized(key: "SendableBriefly")
 # `Sendable`, briefly

 You've been handing values into an actor (`deposit(1)`, `withdraw(80, ...)`)
 and out of it (`await vault.balance`). Anything that crosses an actor or task
 boundary has to be **safe to share**: safe for two isolated domains to hold
 at once without a race. Swift calls that property **`Sendable`**.

 The good news: the value types you use most are already `Sendable`.

 `Int`, `String`, `Bool`, and structs/enums built only from `Sendable` parts
 qualify automatically, because passing them copies the value, nothing is
 shared. That's why every example here compiled without a fuss.

 What's *not* `Sendable` by default is a plain mutable class, exactly the
 `UnsafeLedger` from the start of the chapter, because two domains would
 share one reference to the same mutable memory. Try to send one across a
 boundary and the compiler refuses. (Actors themselves *are* `Sendable`,
 which is why you can freely capture `Ledger` inside those task-group
 closures.)

 That's enough to keep you moving. The full rules (`@Sendable` closures, how
 to make your own types conform, and the `@MainActor` global actor) are the
 whole of the next chapter.

 [Previous](@previous)  |  page 6 of 7  |  [Next: Wrapping Up](@next)
 */
