/*:#localized(key: "ActorsWrappingUp")
 # Wrapping up

 An actor takes the data races you fixed by hand in the chapter [Concurrency Hazards](Concurrency%20Hazards.playgroundchapter/Overview) and turns the
 fix into a guarantee the compiler enforces, by letting only one task inside
 its state at a time. Reach for it to make shared state *safe*, not to make
 code *fast*. Two subtleties, reentrancy and what escapes the actor, are where
 the real learning lives, so weigh the takeaways below carefully.

 * An **actor** is a reference type that protects its mutable state by
 allowing **one task inside at a time**, eliminating data races on that state
 by construction, and it replaces the hand-rolled serial-queue fix, with the
 compiler enforcing the protection so there's no way to accidentally skip it.
 * From **outside**, accessing isolated state needs `await` (you may wait
 your turn); from **inside**, access is synchronous. `nonisolated` opts out
 members that touch only immutable state.
 * **Reentrancy:** an actor is released at every `await`, so another task can
 enter. Values read before an `await` may change after it: keep
 check-then-act free of suspension, or re-check after resuming.
 * Actors are about **safety, not speed.** They serialize access, so a hot
 path funneled through one actor becomes a bottleneck: use them to protect
 shared mutable state, not to parallelize work (that's what task groups are
 for).
 * Values crossing actor/task boundaries must be **`Sendable`**: value types
 usually are, plain mutable classes are not. An actor only protects state
 while it lives inside, so returning a mutable class reference reopens the
 race.

 ---
 
 ## Up next

 The next chapter, [Global Actors and Sendable](Global%20Actors%20and%20Sendable.playgroundchapter/Overview), introduces the
 `@MainActor` that pins work to the UI thread, and tells the full story of
 what makes a type safe to share.

 [Previous](@previous)  |  page 7 of 7
 */
