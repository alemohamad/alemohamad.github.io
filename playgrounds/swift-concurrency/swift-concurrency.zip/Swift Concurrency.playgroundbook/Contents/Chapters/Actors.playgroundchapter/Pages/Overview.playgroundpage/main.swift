/*:#localized(key: "Overview")
 # Actors

 Remember the ticket-counter bank disaster from the chapter [Concurrency Hazards](Concurrency%20Hazards.playgroundchapter/Overview): many tellers pushing
 deposits onto one shared balance at the same time, and the total coming out
 *wrong*, money simply vanishing. That was a **data race**: two tasks reading and
 writing the same memory at once, stepping on each other. Back then you fixed it
 by hand, funneling every change through a serial queue and hoping you never
 forgot. This chapter introduces the modern tool that makes that fix automatic and
 enforced by the compiler: the **actor**.

 ---
 
 ## What you'll learn

 * What an **actor** is, and how it protects mutable state by letting only one
 task inside at a time.
 * Why calling into an actor from outside needs `await`, but code *inside* the
 actor runs synchronously, and what `nonisolated` is for.
 * **Reentrancy**: how an actor can be re-entered across an `await`, the subtle
 bug that causes, and how to guard against it.
 * A first look at **`Sendable`**: the rule for what's safe to hand across actor
 and task boundaries.

 Turn the page and let's meet the bug in its simplest form, one more time.

 page 1 of 7  |  [Next: An actor lets in one task at a time](@next)
 */
