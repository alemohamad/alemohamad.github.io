/*:#localized(key: "DistributedAsyncAndThrows")
 # Distributed calls are `async` *and* `throws`

 Here's the most important difference from a local actor, and the one to burn
 into memory.

 Calling a local actor method is `async`: you `await` it because you might have
 to wait your turn for the actor's isolation. But it does **not** throw just for
 being an actor call; once you're in, the call runs in-process and can't fail on
 the way.

 A **distributed** call is `async` **and** `throws`, because now the call might
 cross a network, and networks fail. The connection can drop, the remote
 machine can be unreachable, a message can time out. None of that can be
 hidden, so the compiler forces you to confront it with `try`:

 ```swift
 // Local actor, await only:
 await ledger.deposit(1)

 // Distributed actor, try await, because the wire can fail:
 try await remoteLedger.deposit(1)
 ```

 Look back at the `distributed func deposit` definition: its body isn't marked
 `throws`, and it never throws on its own. The throwing is added *at the call
 site* by the runtime: it represents **transport failure**, the possibility
 that the message never made the round trip. This is the model being honest
 with you: a remote call is a fundamentally more fragile thing than a local
 one, and the type system won't let you pretend otherwise.

 > **This is `await`'s honesty from the chapter [Async Await Basics](Async%20Await%20Basics.playgroundchapter/Overview), scaled up.**
 > There, `await` marked "this might pause." Here, `try await` on a distributed
 > call marks "this might pause *and* might fail to complete at all." The
 > keywords are doing the same job they always have, making the cost of a call
 > visible at the point you make it.

 [Previous](@previous)  |  page 5 of 9  |  [Next: Codable Arguments](@next)
 */
