/*:#localized(key: "DistributedWhenItMatters")
 # When this actually matters for an app developer

 Let's set honest expectations. **Most iOS app developers will go years without
 writing a distributed actor**, and that's completely normal. Your day-to-day
 concurrency toolkit is the rest of this book: `async`/`await`, tasks, actors,
 `@MainActor`. Distributed actors are a specialist tool, not a daily one.

 Where they *do* earn their place:

 * **Server-side Swift.**  
 If you build backend services in Swift, distributed
 actors and clustering (via Distributed Cluster) offer a native way to spread
 stateful work across a fleet of processes.
 * **Clustered or multi-node systems.**  
 Anything where identical logic runs on
 many machines that must coordinate: the model was designed for exactly this.
 * **Cross-device features.**  
 Forward-looking scenarios where actors on
 different devices talk directly could lean on the same abstraction, given an
 actor system that speaks the right transport.

 If none of those describe what you're building, you don't need distributed
 actors, and knowing they exist, and *how they think*, is the valuable part.
 When you meet `distributed actor` in a server-side codebase someday, it won't
 be a mystery: it's the actor you already understand, with a network in the
 middle and `try` in front of every call.

 [Previous](@previous)  |  page 8 of 9  |  [Next: Wrapping Up](@next)
 */
