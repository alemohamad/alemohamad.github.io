/*:#localized(key: "DistributedCodableArguments")
 # Why arguments and returns must be `Codable`

 A local method call passes arguments as references or values in shared
 memory: the callee sees the very same objects. A distributed call can't do
 that: the callee may be on another machine, with no access to your memory. So
 every argument and every return value has to be **turned into bytes, sent
 across, and rebuilt on the other side**.

 That's why a distributed method's parameters and return type must conform to
 the actor system's **serialization requirement** (for `ClusterSystem` and most
 systems, that's **`Codable`**):

 ```swift
 // A Codable payload can cross the wire; a non-Codable one can't.
 struct Receipt: Codable, Sendable {
     let id: UUID
     let amount: Int
     let newBalance: Int
 }

 distributed actor Ledger {
     typealias ActorSystem = ClusterSystem

     private var balance = 0

     distributed func deposit(_ amount: Int) -> Receipt {
         balance += amount
         return Receipt(id: UUID(), amount: amount, newBalance: balance)
     }
 }
 ```

 `Int` and `Receipt` are `Codable`, so they can make the trip. Try to pass or
 return something that *isn't* encodable (a live database handle, a closure, a
 class with no `Codable` conformance) and the compiler stops you. There's
 simply no way to put a live file handle in an envelope and mail it to another
 computer.

 > **This is `Sendable` from the chapter [Global Actors and Sendable](Global%20Actors%20and%20Sendable.playgroundchapter/Overview), taken one step
 > further.** `Sendable` asks: *is this value safe to hand to another task in the
 > same process?* `Codable` (as a distributed requirement) asks the stricter
 > question: *can this value be flattened into bytes and rebuilt in another
 > process?* Everything that crosses actor-system boundaries needs both: safe to
 > move, *and* possible to serialize. Marking your payload types `Codable,
 > Sendable` together, as `Receipt` does above, is the common idiom.

 * callout(Think about it): Look around one of your own model types. Which of
 its properties would happily cross the wire, and which (a live connection, a
 cached image, a closure) would you have to leave at home and describe with
 plain data instead?

 [Previous](@previous)  |  page 6 of 9  |  [Next: Location Transparency](@next)
 */
