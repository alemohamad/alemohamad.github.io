/*:#localized(key: "DistributedFromOneProcessToMany")
 # From one process to many

 A **distributed actor** is an actor whose callers might be in a *different
 program entirely*. You still `await` its methods; the difference is that the
 call may leave your process, travel over a network to wherever the actor
 actually lives, run there, and send the result back.

 You write it much like a local actor, with two visible changes: the
 `distributed` keyword on the declaration, and `distributed` on each method you
 want to be callable from afar.

 ```swift
 import Distributed

 distributed actor Ledger {
     // Every distributed actor is tied to an actor system, the transport
     // that knows how to find it and deliver messages to it.
     typealias ActorSystem = ClusterSystem

     private var balance: Int = 0

     distributed func deposit(_ amount: Int) {
         balance += amount
     }

     distributed func currentBalance() -> Int {
         balance
     }
 }
 ```

 Notice what *didn't* change: `balance` is still ordinary isolated state, and
 the method bodies read exactly like the local version. The `distributed`
 keyword doesn't change what the method *does*: it marks the method as a
 **message that may arrive from another process**, so the compiler and runtime
 can add the machinery to ship the call across the wire.

 A method *without* `distributed` is still perfectly legal; it just isn't
 callable remotely. It behaves like a normal actor method, reachable only by
 code that already holds a *local* reference to this specific instance.

 [Previous](@previous)  |  page 3 of 9  |  [Next: The Four Pieces](@next)
 */
