/*:#localized(key: "DistributedOverview")
 # Extra credit: Distributed actors

 Back at our ticket-counter bank, an `actor` gave every teller safe, serialized
 access to one shared balance, as long as they all worked in the *same branch*
 (the same process). But banks have many branches. Imagine the balance lives on a
 server, and tellers on iPhones, iPads, and other servers all need to read and
 update it. The workers are now in **different processes on different machines**,
 yet you'd love to keep the exact same mental model: `await` a method on the
 object that owns the state, and let it serialize the access. That's what a
 **distributed actor** is for. This final chapter is a guided tour of the idea,
 not a lab.

 > **This is a read-along chapter, not runnable in Swift Playground.**  
 > Everything else in this book you could run and poke at. Distributed actors are
 > different: they need `import Distributed` *and* a live **actor system** (a
 > networking runtime that ships messages between machines). That transport isn't
 > available in the Swift Playground app out of the box, so the distributed
 > snippets ahead are **illustrative**: they show the *shape* of the API, not code
 > you can paste and run here. The one place you *can* run something is the plain
 > local `actor` recap, clearly marked **Runnable**. Read this chapter for the
 > concepts; reach for a full Swift package on a Mac when you want to actually try
 > it.

 ---

 ## What you'll learn

 * How a **distributed actor** extends the local `actor` model across processes
 and machines, keeping the same `await`-to-call feel.
 * The four pieces that make it work: the `distributed actor`, its `distributed`
 methods, the **`ActorSystem`** (the transport), and the actor's **`ID`**.
 * Why calls to distributed methods are `async` **and** `throws`, and how that
 differs from a local actor.
 * Why arguments and return values must be **`Codable`**, and how that ties back
 to `Sendable` from the chapter [Global Actors and Sendable](Global%20Actors%20and%20Sendable.playgroundchapter/Overview).
 * What **location transparency** buys you, and the honest costs that come with
 it.
 * When any of this actually matters for an app developer (spoiler: rarely, and
 that's fine).

 When you're ready, turn to the next page for a quick recap of the local actor
 you already know, the foundation everything else builds on.

 page 1 of 9  |  [Next: Local Actor Recap](@next)
 */
