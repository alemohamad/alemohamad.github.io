/*:#localized(key: "ClassicModelTaxes")
 # The classic model, and the taxes it charges

 Everything in the classic model shared one shape: you started some work, handed it
 a **closure** (a completion handler) to run *later*, and moved on. That closure is
 the seam where the classic model quietly bills you. Five charges show up again and
 again:

 * **Completion handlers everywhere.**  
 Every async step ends by calling *your* closure. Nothing runs after an async call 
 the way a normal line does; it all has to live *inside* the handler.
 * **The pyramid of doom.**  
 When step B needs step A's result, B's call goes inside A's handler. Add step C 
 and you nest again. The code marches to the right.
 * **Errors that can't use `throws`.**  
 A completion handler isn't a function you `return` from, so you can't `throw`. 
 Errors travel as values you must manually route to every caller.
 * **Forgetting to call back.**  
 On *some* path (an early `return`, an error branch) it's easy to forget to call 
 the completion. The caller then waits forever, with no crash to point at the 
 mistake.
 * **Forgetting the main-thread hop.**  
 Results arrive on a background queue. Touch the UI from there and you've got a 
 bug that only *sometimes* shows. You must remember to hop back to the main thread 
 by hand.

 You met the last of the manual bookkeeping in the chapter [Operation Dependencies and Cancellation](Operation%20Dependencies%20and%20Cancellation.playgroundchapter/Overview): wiring dependencies
 between operations, threading a cancellation flag through each one, checking it at
 the right moments. Powerful, but all on you. Let's watch these taxes pile up in one
 small job.

 [Previous](@previous)  |  page 2 of 6  |  [Next: A Job in Three Steps](@next)
 */
