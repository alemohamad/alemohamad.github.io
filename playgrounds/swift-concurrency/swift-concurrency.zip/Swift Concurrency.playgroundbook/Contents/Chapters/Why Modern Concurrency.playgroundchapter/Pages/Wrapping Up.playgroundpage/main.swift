/*:#localized(key: "WrappingUp")
 # Wrapping up

 The classic model isn't broken; it just charges you bookkeeping at every seam, and
 this chapter is about seeing those recurring taxes clearly. `async`/`await`
 rewrites the *same* work as straight-line code the compiler helps you get right. A
 few habits need unlearning on the way in, which is what the takeaways below are
 for.

 * The classic model charges recurring taxes: nesting for dependent steps, no
 `throws`, callbacks you can forget, and manual main-thread hops.
 * Chained async calls grow into the **pyramid of doom** (the logic marches right
 and error handling scatters across branches) because each step *depends* on the
 last, not because callbacks are at fault.
 * `async`/`await` rewrites the *same* work as straight-line code with one
 `do-try-catch`, and the compiler enforces the error handling for you.
 * Modern concurrency's first gift is **clarity and safety**, not raw speed; and
 `await` is a point where the function can *suspend and let the thread do other
 work*, not a line that blocks.
 * You won't drop callbacks entirely; you'll still meet completion-handler APIs and
 wrap them into `await`.
 * The three pillars ahead are **`async`/`await`**, **structured concurrency**
 (task trees with automatic cancellation and error propagation), and **actors**
 (compiler-checked data-race safety).

 ---
 
 ## Up next

 [async/await basics](Async%20Await%20Basics.playgroundchapter/Overview): what `async` and `await` actually mean, how a function
 suspends and resumes, and how to define and call your own async functions.

 [Previous](@previous)  |  page 6 of 6
 */
