/*:#localized(key: "Overview")
 # Why Modern Concurrency

 ![Modern Concurrency in Swift](Swift.png)

 You've spent all of the classic chapters moving work off the main thread by hand:
 dispatching to queues, waiting on groups, guarding shared state, wrapping jobs as
 operations and wiring up their dependencies. It works, but every one of those tools
 handed the *bookkeeping* back to you. In this chapter you'll feel exactly where the
 classic model gets heavy, then get your first look at the model designed to fix it.
 No new syntax to memorize yet; just the *why* behind everything in the modern
 model.

 ---
 
 ## What you'll learn

 * The recurring "taxes" the classic, closure-based model charges you.
 * Why chained async calls collapse into the **pyramid of doom**.
 * How closures block you from using `throws` / `do-try-catch` for errors.
 * A visceral before/after: the same job as callbacks, then as `async`/`await`.
 * The three pillars of modern concurrency you'll learn hands-on next.

 When you're ready, turn to the next page and we'll start counting the taxes.

 page 1 of 6  |  [Next](@next)
 */
