/*:#localized(key: "TaskTree")
 # The task tree

 Because tasks create child tasks, they form a **tree**: a parent with
 children, those children with children of their own. Two things flow along the
 branches of that tree, and both matter:

 * **Errors flow up.**  
 If a structured child throws, the error propagates to the parent's `await`, 
 and the parent's *other* children are cancelled automatically.
 * **Cancellation flows down.**  
 When you cancel a task, every task beneath it in the tree is marked cancelled too.

 That downward flow is what makes cancellation manageable. You cancel *one*
 task (the screen's task) and every child it spawned learns it should wind
 down. You don't have to track them all yourself; the tree does it for you.

 Next, you'll see what cancelling a task actually does under the hood.

 [Previous](@previous)  |  page 6 of 11  |  [Next: Cooperative Cancellation](@next)
 */
