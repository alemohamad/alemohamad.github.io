/*:#localized(key: "Overview")
 # Tasks and Cancellation

 Back at the corner coffee bar, a customer orders a slow pour-over, waits ten
 seconds... then says "actually, never mind" and walks out. A good barista stops
 pouring and moves on. A bad one keeps pouring into a cup no one will drink. Your
 code faces the same choice constantly: a screen the user already dismissed, a
 search they already retyped, a download they already backed out of. In the last
 chapter you learned to *start* async work with `await`. This chapter is about the
 thing that runs it (the **task**) and how to tell one to stop.

 ---
 
 ## What you'll learn

 * What a `Task` really is: it starts immediately, carries a priority, and inherits
 context from where you create it.
 * How to get a value back out of a task with `task.value` and `task.result`.
 * **Structured** vs. **unstructured** tasks, and why the difference matters.
 * **Cooperative cancellation**: how `cancel()` works, and why your code has to
 *check* for it.
 * What cancellation is *not*: it never forces anything to stop.

 Turn to the next page to watch a task start running the moment you create it.

 page 1 of 11  |  [Next: A Task Starts Immediately](@next)
 */
