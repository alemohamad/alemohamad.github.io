/*:#localized(key: "TaskDetached")
 # `Task.detached`: the one that inherits nothing

 A normal `Task { }` inherits **context** from where it's created: the current
 **priority** (how urgent the work is) and the current **actor** (a later
 chapter covers actors in depth: think of it as "which thread-safe world this
 code runs in"). Inheriting that context is almost always what you want.

 `Task.detached { }` deliberately inherits *none* of it. It starts from a blank
 slate: default priority, no actor. This is a sharp tool you'll reach for
 rarely.
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

Task(priority: .high) {
    print("parent priority:   \(Task.currentPriority.rawValue)")

    Task {
        print("child (Task):      \(Task.currentPriority.rawValue)")
    }

    Task.detached {
        print("detached:          \(Task.currentPriority.rawValue)")
    }
}

// The two child tasks above are fire-and-forget: nothing joins them, so we
// give them a moment to print, then stop the page.
Task {
    try? await Task.sleep(for: .milliseconds(300))
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "TaskDetached-2")
 **Watch it run:** the parent and the plain `Task` child report the *same*
 priority number (high is `25`), while the detached task reports a different,
 default value (medium is `21`); it didn't inherit anything. The exact numbers
 are an implementation detail; the point is that the inheriting child matches
 its parent and the detached one does not.

 > **When would you actually want `Task.detached`?** Almost never. Use it only
 > when a piece of work is genuinely independent of its origin: say, kicking off
 > a fire-and-forget cache write that shouldn't ride on a high-priority screen's
 > urgency, or shouldn't be tied to that screen's actor. If you're unsure, you
 > don't need it: reach for a plain `Task`.

 [Previous](@previous)  |  page 5 of 11  |  [Next: The Task Tree](@next)
 */
