/*:#localized(key: "PrioritiesAndYielding")
 # A quick word on priorities and `Task.yield()`

 Every task carries a **priority**: a hint about how urgent it is, from
 `.high` down through `.medium`, `.low`, and `.background`. The system uses it
 to decide what to run first when work piles up; it's a hint, not a guarantee.
 You set it with `Task(priority: .background) { ... }`, and, as you saw, child
 tasks inherit it.

 If you have a long CPU-bound loop with *no* `await` in it, it can hog a
 thread and starve other tasks. Dropping in `await Task.yield()` gives the
 system a chance to run something else: a voluntary breather, and also a
 suspension point where cancellation can be noticed.

 The next chapter closes with a recap of the ideas that make cancellation
 trustworthy.

 [Previous](@previous)  |  page 10 of 11  |  [Next: Wrapping Up](@next)
 */
