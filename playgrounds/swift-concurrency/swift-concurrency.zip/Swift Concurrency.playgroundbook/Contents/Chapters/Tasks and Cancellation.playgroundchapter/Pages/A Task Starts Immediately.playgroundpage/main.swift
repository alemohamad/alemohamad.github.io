/*:#localized(key: "TaskStartsImmediately")
 # A task begins running the moment you create it

 A **task** is a unit of asynchronous work that the system runs for you. You've
 already been creating them: every `Task { }` in this book is one. The first thing
 to internalize: **a task begins running the instant you create it.** You don't
 "start" it; making it *is* starting it.
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

print("Before the task")

let brew = Task {
    print("  Task: grinding beans")
    try await Task.sleep(for: .milliseconds(300))
    print("  Task: coffee ready")
    PlaygroundPage.current.finishExecution()
}

print("After the task (this line doesn't wait)")
//#-end-editable-code
/*:#localized(key: "TaskStartsImmediately-2")
 **Watch it run:** you'll see `Before the task`, then `After the task...`, and only
 later the two lines from inside the task. The task ran *alongside* your top-level
 code; creating it didn't block the line after it. That's the same suspension you
 met in the previous chapter, now with a handle (`brew`) you can hold onto.

 * callout(Try it): Drop the sleep to `.milliseconds(1)`. Do the task's two lines
 still print *after* `After the task...`, or does the ordering flip?

 [Previous](@previous)  |  page 2 of 11  |  [Next: Getting a Value Back](@next)
 */
