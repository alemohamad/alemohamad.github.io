/*:#localized(key: "RunningClassicModel")
 # Running the examples in the classic model

 Everything in this book runs in the **Swift Playground app** on **iPad or Mac**,
 no Xcode required. That brings one habit you would not need in an Xcode app, and it
 applies to *both* the classic and the modern chapters, so it is worth meeting now.

 A Playground page runs your code top to bottom and then **ends**. Asynchronous
 work (a GCD block here, a `Task` on the next page) runs *later*, so the page can
 quit before that work ever prints. To prevent that you `import PlaygroundSupport`
 and set `needsIndefiniteExecution`, which keeps the page alive; when the work is
 done you call `finishExecution()` to let it stop.

 **Here is the classic version.**  
 GCD runs its closure later on a background queue,
 so we keep the page alive first, then stop it from inside the closure. Run the code.
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

DispatchQueue.global().async {
    print("Work done on a background queue")
    PlaygroundPage.current.finishExecution()
}
//#-end-editable-code
/*:#localized(key: "RunningClassicModel-2")
 Without `needsIndefiniteExecution`, the page can end before the background work
 prints anything. You'll see this pattern throughout the chapters, so it's
 worth meeting now.

 * callout(Try it): Comment out the `finishExecution()` line and run again. The
 output still appears, but notice the page keeps running (it never stops on its own).

 [Previous](@previous)  |  page 3 of 6  |  [Next: Running Modern Model](@next)
 */
