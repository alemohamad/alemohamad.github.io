/*:#localized(key: "IntroWrappingUp")
 # Wrapping up

 This book is a tour of one idea across two eras: the classic model first, then
 the modern one built to answer its pains. Everything ahead aims at a single goal,
 keeping your app responsive while real work happens out of sight. Here's the
 shape of what's coming.

 * Concurrency is structuring work so waiting or heavy work doesn't freeze the rest.
 * You'll learn the **classic** model (GCD, Operations) then the **modern** model
 (`async`/`await`, actors), and why the second exists.
 * Keep asyncronous pages alive with
 `needsIndefiniteExecution` from the `PlaygroundSupport` framework.

 ---

 ## Up next

 **[Why concurrency](Why%20Concurrency.playgroundchapter/Overview)**: what actually goes wrong without it, and the difference between
 concurrency and parallelism.

 [Previous](@previous)  |  page 6 of 6

 * callout(A note from the author): Thanks for reading this far! This book is an
 independent project, written and maintained by one person, so it may
 contain mistakes or explanations that could be clearer. If you found an error,
 or a passage that confused you, I would really like to know, since your feedback
 is how the book improves for the next reader. Corrections, questions, and
 suggestions are all welcome.  
 You can reach me here: [X](https://x.com/alemohamad) /
 [Mastodon](https://mastodon.social/@alemohamad) /
 [Bluesky](https://bsky.app/profile/alemohamad.com) /
 [LinkedIn](https://www.linkedin.com/in/alemohamad/)
 */
