/*:#localized(key: "RunningModernModel")
 # Running the examples in the modern model

 The modern chapters need the same keep-alive habit you met on the previous page,
 and for the same reason: a `Task`'s work runs *after* the page's top-level code, so
 the page would end before you saw any output.

 **Modern async code goes in a `Task`.** A Playground page runs top to bottom; to
 use `await`, you wrap the work in a task.  
 As with the classic page, you
 `import PlaygroundSupport`, keep the page alive, and stop it once the task is done.
 Run the code below.
 */
//#-editable-code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

func greet() async -> String {
    "Hello from an async function"
}

Task {
    let message = await greet()
    print(message)

    PlaygroundPage.current.finishExecution()
}

print("This line runs first (the task hasn't finished yet).")
//#-end-editable-code
/*:#localized(key: "RunningModernModel-2")
 **Watch it run:** you'll see `This line runs first...` printed *before* the
 greeting. That's your very first taste of suspension: the `Task` runs alongside the
 rest of the page, so the last line doesn't wait for it. The page stops on its own
 the moment the task calls `finishExecution()`, no matter how long the work takes.

 * callout(Try it): Add a second `print` *inside* the `Task`, after the greeting.
 Does it land before or after the "runs first" line?

 [Previous](@previous)  |  page 4 of 6  |  [Next: How This Book Works](@next)
 */
