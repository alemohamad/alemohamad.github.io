/*:#localized(key: "HowThisBookWorks")
 # How this book works

 Every chapter follows the same rhythm so you always know where you are:

 * A **problem** to motivate the idea.
 * **Runnable examples** you should actually run, then change, and run again.
 * A **Watch it run** cue telling you what to look for (concurrency output is often
 surprising).
 * Small **Try it** nudges inviting one change, so you can predict the result and
 then check it.
 * A **Wrapping up** with the key takeaways and the common pitfalls, to lock it in.

 The single most valuable thing you can do: **change the examples and predict the
 output before you run.** When your prediction is wrong, you've just found the exact
 edge of your mental model, which is precisely where learning happens.

 The scenarios in this book (a coffee bar, a weather station, a print shop, a
 photo-stacking astronomy tool, a bank counter) run throughout so
 ideas accumulate. They're deliberately small and physical, because concurrency is
 easier to feel when you can picture real workers and real counters than when it's
 abstract "tasks" and "threads."

 [Previous](@previous)  |  page 5 of 6  |  [Next: Wrapping Up](@next)
 */
