/*:#localized(key: "Welcome")
 # Welcome to Swift Concurrency

 You've shipped apps. Buttons work, screens push, data loads. Then one day a list
 stutters while an image loads, or a value is mysteriously wrong "sometimes," or
 the app freezes for a beat when you tap. Every one of those is a **concurrency**
 problem: code that needs to do more than one thing at a time, done in a way that
 either fought you or bit you. This book is about doing it on purpose, and doing it
 right.

 * callout(What you'll learn):
   * What this book covers and the order it builds in.
   * How to run and experiment with every example inside Swift Playground.
   * A first mental model for "more than one thing at a time."
   * The two eras of Swift concurrency, and why you need both.

 Turn to the next page for the one sentence that the whole book hangs on.

 page 1 of 6  |  [Next: The Mental Model](@next)
 */
