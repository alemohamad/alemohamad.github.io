/*:#localized(key: "MentalModel")
 # The mental model, and the two eras that serve it

 **Concurrency is about structuring your program so that work which would otherwise
 block (waiting, or hogging the processor) doesn't freeze everything else.**

 Hold onto that sentence. Every tool in this book (queues, operations, await,
 actors) is just a different way to honor it.

 Swift gives you two toolkits for that job, and you'll meet both:
 
 * **The classic model**: Grand Central Dispatch (GCD) and
   Operations.  
   This is C-era, closure-based machinery that has powered Apple
   platforms for over a decade. You still read it in every codebase, and it teaches
   the raw ideas (threads, queues, races) with nothing hidden.
 * **The modern model**: async/await, structured concurrency, and
   actors, introduced in Swift 5.5.  
   It bakes safety into the language and reads
   like ordinary top-to-bottom code.
 
 Learning the classic model first isn't nostalgia. The modern model was designed as
 an *answer* to specific pains in the old one. If you feel those pains yourself
 first, the new tools feel less like magic and more like relief. The closing chapter
 puts them side by side.
 
 > In new code you'll reach for the modern model almost every
 > time. But you'll still meet GCD in existing apps, in Apple's own APIs, and
 > whenever you need to understand *what `await` is actually doing underneath*.

 [Previous](@previous)  |  page 2 of 6  |  [Next: Running Classic Model](@next)
 */
