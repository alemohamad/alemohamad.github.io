import UIKit
import PlaygroundSupport

class CutsceneStackView: UIStackView {
    let colorTitle = UIColor.white
    // let colorSubtitle = UIColor(red: 29.0/255.0, green: 54.0/255.0, blue: 102.0/255.0, alpha: 1.0)
    let colorSubtitle = UIColor(red: 29.0/255.0, green: 54.0/255.0, blue: 102.0/255.0, alpha: 1.0)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupStackView()
    }
    
    required init(coder: NSCoder) {
        super.init(coder: coder)
        setupStackView()
    }
    
    func setupStackView() {
        axis = .vertical
        alignment = .leading
        spacing = -10
        
        createLabels()
    }
    
    func createLabel(_ text: String, color: UIColor, size: CGFloat = 80, weight: UIFont.Weight = .bold) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.systemFont(ofSize: size, weight: weight)
        label.textColor = color
        return label
    }
    
    // Cover text is localized. Each language provides these keys in its
    // <lang>.lproj/Localizable.strings; the English `value:` here is the
    // source and also the fallback if a translation is missing. The title is
    // two colored lines so each language can split it where it reads best.
    func coverText(_ key: String, _ english: String) -> String {
        NSLocalizedString(key, tableName: nil, bundle: .main, value: english, comment: "Book cover")
    }

    func createLabels() {
        let title1 = createLabel(coverText("cover_title_line1", "Learn Swift"), color: colorTitle)
        let title2 = createLabel(coverText("cover_title_line2", "Concurrency"), color: colorSubtitle)
        let spacer = createLabel(" ", color: colorTitle, size: 48)
        let subtitle = createLabel(coverText("cover_subtitle", "The classic and modern models"), color: colorSubtitle, size: 36, weight: .regular)
        
        addArrangedSubview(title1)
        addArrangedSubview(title2)
        addArrangedSubview(spacer)
        addArrangedSubview(subtitle)
    }
}

class GradientView: UIView {
    private var gradientLayer: CAGradientLayer?
    
    func addGradientBackground(topColor: UIColor, bottomColor: UIColor) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [topColor.cgColor, bottomColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        self.layer.insertSublayer(gradientLayer, at: 0)
        self.gradientLayer = gradientLayer
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer?.frame = bounds
    }
}

let cutsceneStackView = CutsceneStackView()
cutsceneStackView.translatesAutoresizingMaskIntoConstraints = false

let containerView = UIView()
containerView.translatesAutoresizingMaskIntoConstraints = false
containerView.addSubview(cutsceneStackView)

NSLayoutConstraint.activate([
    cutsceneStackView.leadingAnchor.constraint(equalTo: containerView.safeAreaLayoutGuide.leadingAnchor, constant: 60),
    cutsceneStackView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 120)
])

let colorTop = UIColor(red: 239.0/255.0, green: 150.0/255.0, blue: 54.0/255.0, alpha: 1.0)
let colorBottom = UIColor(red: 217.0/255.0, green: 95.0/255.0, blue: 40.0/255.0, alpha: 1.0)

let rootView = GradientView()
rootView.addGradientBackground(topColor: colorTop, bottomColor: colorBottom)

rootView.addSubview(containerView)

containerView.translatesAutoresizingMaskIntoConstraints = false

NSLayoutConstraint.activate([
    containerView.leadingAnchor.constraint(equalTo: rootView.leadingAnchor),
    containerView.topAnchor.constraint(equalTo: rootView.topAnchor),
    containerView.trailingAnchor.constraint(equalTo: rootView.trailingAnchor),
    containerView.bottomAnchor.constraint(equalTo: rootView.bottomAnchor)
])

PlaygroundPage.current.liveView = rootView
