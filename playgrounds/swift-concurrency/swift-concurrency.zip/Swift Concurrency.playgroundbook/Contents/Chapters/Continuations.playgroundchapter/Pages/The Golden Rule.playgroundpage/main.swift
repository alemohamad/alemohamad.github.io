/*:#localized(key: "TheGoldenRule")
 # The golden rule: resume exactly once

 Everything about continuations comes down to one law:

 **You must resume a continuation exactly once. Never zero times. Never
 twice.**

 Both failures are quiet in the moment and vicious later:

 * **Resume zero times**:  
 You take the continuation, then some path (an
 early `return`, a `guard`, an error branch you forgot) skips the resume. The
 async function that awaited you **suspends forever**. No crash, no log by
 default: just a task frozen for the life of the program, holding whatever it
 captured. That's the trap the "neither value nor error" branch on the
 previous page avoids.
 * **Resume twice**:  
 Two callbacks fire, or you resume in a loop, or a retry
 calls back a second time. The second resume corrupts the concurrency
 runtime.

 This is why you use the **checked** variants: `withCheckedContinuation` and
 `withCheckedThrowingContinuation`. "Checked" means the runtime *watches*
 your continuation for exactly these two mistakes:

 * Resume it **twice** and it deliberately **traps**: a hard crash with a
 message like `SWIFT TASK CONTINUATION MISUSE: ... tried to resume its
 continuation more than once`. Loud on purpose: a double-resume is a real
 bug, and a clear crash in testing beats mysterious corruption in
 production.
 * Let it **leak** (deallocated without ever being resumed) and it logs a
 warning like `... leaked its continuation without resuming it`, telling you
 exactly which wrapper hung.

 There's a `withUnsafeContinuation` pair without these checks. Ignore it
 while you're learning: the checked versions cost almost nothing and turn
 silent hangs and corruption into loud, findable problems. Reach for
 "unsafe" only once a wrapper is proven correct and you've measured that the
 check matters.

 The practical habit: for **every** path through your callback (success,
 each error, the impossible-looking `else`), ask "does this resume the
 continuation?" Exactly one resume must happen on every path.

 [Previous](@previous)  |  page 5 of 8  |  [Next: Bridging a Delegate](@next)
 */
