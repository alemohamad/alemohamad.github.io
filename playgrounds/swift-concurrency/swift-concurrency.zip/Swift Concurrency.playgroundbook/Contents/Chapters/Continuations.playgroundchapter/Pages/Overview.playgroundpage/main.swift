/*:#localized(key: "Overview")
 # Continuations

 By now `await` feels natural, but most code out there doesn't speak it. The
 classic completion handlers from earlier chapters, every `DispatchQueue` hop,
 every delegate method that fires "later" (and countless system and SDK APIs
 you'll meet in real projects) are **callback** APIs, not async ones. You can't
 sprinkle `await` on `fetchThing { ... }` and hope. A **continuation** is the
 official adapter: it lets you wrap one of those old callback APIs so the
 outside world can call it with a clean `await`. This chapter is how you build
 that adapter by hand.

 ---
 
 ## What you'll learn

 * What a **continuation** is, and why it's the bridge from callbacks to
 `await`.
 * `withCheckedContinuation`: suspend an async function, run a callback API,
 and **resume** when the callback fires.
 * `withCheckedThrowingContinuation` for APIs that can fail, wrapping both
 `Result` and the classic `(value, error)` shape.
 * The one rule you must never break: **resume exactly once**, and how
 "checked" continuations catch you when you slip.
 * How to bridge a **delegate**-style, single-shot callback into one async
 call.

 ---
 
 ## The bridge you need

 Here's the mismatch. An async function makes progress top-to-bottom and
 **suspends** at each `await`, handing the thread back until its result is
 ready. A callback API doesn't return a result at all: it hands you a closure
 and calls it **later**, from wherever it finished. Two different worlds.

 A **continuation** is a value that represents "the rest of the suspended
 async function, waiting to be handed a result." You get one, stash it, call
 your old callback API, and when the callback fires you **resume** the
 continuation with the value. That resume is what wakes the async function
 back up.

 The shape is always the same:

 ```swift
 func modernVersion() async -> Result {
     await withCheckedContinuation { continuation in
         oldCallbackAPI { value in                   // the callback fires later...
             continuation.resume(returning: value)   // ...and wakes us up
         }
     }
 }
 ```

 The `await withCheckedContinuation { ... }` call **suspends** right there. It
 won't return until *someone* calls `continuation.resume(...)`. The closure
 you pass runs immediately (that's where you kick off the old API), but the
 `await` itself parks until the resume lands.

 On the next page we'll build a real one and watch it suspend and resume.

 page 1 of 8  |  [Next: Suspend, Then Resume](@next)
 */
