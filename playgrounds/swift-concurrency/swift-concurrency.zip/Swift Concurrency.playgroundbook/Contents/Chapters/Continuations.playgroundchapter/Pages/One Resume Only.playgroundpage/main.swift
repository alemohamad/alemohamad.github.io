/*:#localized(key: "OneResumeOnly")
 # One resume only: for streams, use `AsyncStream`

 A continuation is strictly single-shot: one suspend, one resume, one value.
 If your callback fires **many** times (a sensor emitting readings, a socket
 delivering messages, a location manager streaming updates), a continuation
 is the wrong tool. The *second* resume would trap.

 That's exactly what `AsyncStream` from the chapter [AsyncSequence and AsyncStream](AsyncSequence%20and%20AsyncStream.playgroundchapter/Overview) is for: it wraps a
 callback that fires repeatedly into an `AsyncSequence` you `for await` over.
 The rule of thumb:

 * **One callback, one result → continuation** (this chapter).
 * **A callback that keeps firing → `AsyncStream`** (the chapter [AsyncSequence and AsyncStream](AsyncSequence%20and%20AsyncStream.playgroundchapter/Overview)).

 [Previous](@previous)  |  page 7 of 8  |  [Next: Wrapping Up](@next)
 */
