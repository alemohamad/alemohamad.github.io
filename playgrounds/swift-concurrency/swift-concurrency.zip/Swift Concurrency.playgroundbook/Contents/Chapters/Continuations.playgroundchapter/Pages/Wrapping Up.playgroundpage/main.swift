/*:#localized(key: "WrappingUp")
 # Wrapping up

 A continuation is the adapter that lets the modern world `await` an old
 callback API: suspend at `await`, resume when the callback fires.
 Everything rests on one law, **resume exactly once** on every path, and
 most of the takeaways below are that single law seen from different
 angles.

 * A **continuation** bridges a callback/completion/delegate API into
 `async`/`await`: suspend at `await`, resume when the callback fires.
 * `withCheckedContinuation` for callbacks that always succeed;
 `withCheckedThrowingContinuation` (plus `resume(throwing:)`) for ones that
 can fail. `resume(with:)` unwraps a `Result` in one line.
 * The golden rule: **resume exactly once** on every path; trace each
 branch. Zero resumes → a silent hang; two → a crash. Guard a
 possibly-repeating callback by nil-ing out the stored continuation after
 the first resume.
 * **Checked** continuations catch both: they trap on a double-resume and
 warn on a leaked (never-resumed) continuation; don't silence that warning,
 and prefer checked over `withUnsafeContinuation` while learning.
 * Bridge a **single-shot delegate** with a small adapter that resumes in
 its delegate methods, and keep a strong reference to it alive until it
 resumes, or a `weak` delegate can be freed early and leak the
 continuation.
 * A continuation is one-and-done. For callbacks that fire repeatedly, use
 `AsyncStream` from the chapter [AsyncSequence and AsyncStream](AsyncSequence%20and%20AsyncStream.playgroundchapter/Overview).

 ---
 
 ## Up next

 **[Task groups](Task%20Groups.playgroundchapter/Overview)**: now that a single async call is easy, how do you run
 *many* of them at once and gather all the results, safely and in parallel?

 [Previous](@previous)  |  page 8 of 8
 */
