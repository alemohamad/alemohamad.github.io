import UIKit
import PlaygroundSupport

let imageView = UIImageView(image: #imageLiteral(resourceName: "Playground Project.png"))
imageView.contentMode = .scaleAspectFit
PlaygroundPage.current.setLiveView(imageView)
