/*:#localized(key: "Armstrong")
 ## Armstrong Numbers
 
 **Goal:** Write a function to determine if a given integer is an Armstrong number.
 
 An Armstrong number (or narcissistic number) for a given number of digits is a number that is equal to the sum of its digits each raised to the power of the number of digits.
 
 For example, **153** is an Armstrong number because `1³ + 5³ + 3³ = 153`.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `isArmstrong(_:)` that takes an integer as input.
 2.	Calculate the sum of each digit raised to the power of the total number of digits.
 3.	Return `true` if the number is an Armstrong number, otherwise `false`.
 
 * Callout(Extra challenge):
   Extend the function to find all Armstrong numbers within a given range (e.g., 1 to 1000).
 */
import Foundation
