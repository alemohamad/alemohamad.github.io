/*:#localized(key: "Palindrome")
 ## Palindrome Numbers
 
 **Goal:** Write a function that determines if a given integer is a palindrome.
 
 A palindrome is a number that reads the same forward and backward, such as **121** or **12321**.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `isPalindrome(_:)` that takes an integer as input.
 2.	Check if the number reads the same backward as it does forward.
 3.	Return `true` if the number is a palindrome, otherwise `false`.
 
 * Callout(Extra challenge):
   Modify the function to check if strings are palindromes as well.
 */
import Foundation
