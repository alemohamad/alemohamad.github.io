/*:
 ## Palindrome Numbers
 
 Write a function that determines if a given integer is a palindrome.
 
 A palindrome is a number that reads the same forward and backward, such as **121** or **12321**.
 
 1. Define a function named `isPalindrome(_:)` that takes an integer as input.
 2.	Check if the number reads the same backward as it does forward.
 3.	Return `true` if the number is a palindrome, otherwise `false`.
 
 > • Convert the number to a string to easily compare the forward and reversed forms.  
 > • Alternatively, use mathematical operations to reverse the number without converting it to a string.
 
 - Experiment: Modify the function to check if strings are palindromes as well.
 */
import Foundation
