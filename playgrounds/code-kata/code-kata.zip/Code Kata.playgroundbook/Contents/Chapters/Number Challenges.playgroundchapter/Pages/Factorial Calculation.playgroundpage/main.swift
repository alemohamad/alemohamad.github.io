/*:
 ## Factorial Calculation
 
 Write a function that calculates the factorial of a given number.
 
 The factorial of a non-negative integer **n** is the product of all positive integers less than or equal to **n** and is represented as **n!**.
 
 1. Define a function named `factorial(_:)` that takes an integer parameter.
 2.	Calculate the factorial by multiplying the numbers from 1 up to the given number.
 3.	Return the result as an integer.
 
 > • Use recursion or a loop to compute the factorial.  
 > • Remember that `0! = 1` by definition.
 
 - Experiment: Modify the function to handle larger numbers by returning the result as a `Double` or `BigInt` if necessary.
 */
import Foundation
