/*:
 ## Fizz Buzz
 
 Write a function that iterates over a range of numbers.
 
 For each number print **"Fizz"** if divisible by 3, **"Buzz"** if divisible by 5, **"FizzBuzz"** if divisible by both. Otherwise, print the number.
 
 1. Define a function named `fizzBuzz(range:)` that accepts an integer range (e.g., `1...100`) as a parameter.
 2.	Use a loop to iterate over each number in the range.
 3.	Apply the divisibility conditions to determine the appropriate output for each number.
 4.	Print the result for each number.
 
 > • Use the modulus operator `%` to check divisibility.  
 > • This challenge is a classic for technical interviews because it tests understanding of control flow and basic conditional logic.
 
 - Experiment: Try modifying the range or divisors to see how the output changes.
 */
import Foundation
