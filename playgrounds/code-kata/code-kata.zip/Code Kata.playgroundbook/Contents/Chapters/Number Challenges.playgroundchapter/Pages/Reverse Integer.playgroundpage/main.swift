/*:
 ## Reverse Integer
 
 Write a function that reverses the digits of a given integer.
 
 If the reversed integer exceeds the standard 32-bit signed integer range `[-2³¹, 2³¹ - 1]`, return 0.
 
 1. Define a function named `reverseInteger(_:)` that takes an integer as input.
 2. Reverse the digits of the number.
 3. If the reversed integer is outside the range of a 32-bit signed integer, return 0. Otherwise, return the reversed integer.
 
 > • Use modulus and division to extract and reverse the digits.  
 > • Check for overflow by comparing the reversed integer to the 32-bit range.
 
 - Experiment: Allow the function to handle larger integer types if possible.
 */
import Foundation
