/*:#localized(key: "SumDigits")
 ## Sum of Digits
 
 **Goal:** Write a function that calculates the sum of the digits of a given integer.
 
 For example, the sum of the digits of **123** is **1 + 2 + 3 = 6**.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `sumOfDigits(_:)` that takes an integer as input.
 2.	Extract each digit of the number and calculate the sum.
 3.	Return the sum as an integer.
 
 * Callout(Extra challenge):
   Extend the function to sum the digits of all numbers within a specified range, e.g., from 1 to 100.
 */
import Foundation
