/*:#localized(key: "LCM")
 ## Least Common Multiple (LCM)
 
 **Goal:** Write a function that calculates the least common multiple (LCM) of two integers.
 
 The LCM is the smallest positive integer that is divisible by both numbers.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `lcm(_:_:)` that takes two integers as input.
 2.	First, find the GCD (greatest common divisor) of the two numbers. Then, use this relationship: the LCM is the product of the two numbers divided by their GCD.
 3.	Return the LCM as an integer.
 
 * Callout(Extra challenge):
   Extend the function to find the LCM of an array of integers.
 */
import Foundation
