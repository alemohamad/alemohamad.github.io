/*:#localized(key: "Fibonacci")
 ## Fibonacci Sequence
 
 **Goal:** Write a function that generates the Fibonacci sequence up to a specified number of terms.
 
 The Fibonacci sequence is a series of numbers where each number is the sum of the two preceding ones, starting from 0 and 1.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `fibonacciSequence(count:)` that takes an integer parameter representing the number of terms.
 2.	Use a loop or recursion to generate each term in the sequence.
 3.	Return an array containing the sequence up to the specified count.
 
 * Callout(Extra challenge):
   Create a function that returns only the nth Fibonacci number instead of the whole sequence.
 */
import Foundation
