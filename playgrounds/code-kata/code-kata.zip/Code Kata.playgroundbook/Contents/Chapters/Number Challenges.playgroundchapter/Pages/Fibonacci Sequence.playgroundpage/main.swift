/*:
 ## Fibonacci Sequence
 
 Write a function that generates the Fibonacci sequence up to a specified number of terms.
 
 The Fibonacci sequence is a series of numbers where each number is the sum of the two preceding ones, starting from 0 and 1.
 
 1. Define a function named `fibonacciSequence(count:)` that takes an integer parameter representing the number of terms.
 2.	Use a loop or recursion to generate each term in the sequence.
 3.	Return an array containing the sequence up to the specified count.
 
 > • Start with 0 and 1 as the first two terms.  
 > • For efficiency, use an iterative approach if possible.
 
 - Experiment: Create a function that returns only the nth Fibonacci number instead of the whole sequence.
 */
import Foundation
