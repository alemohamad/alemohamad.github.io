/*:
 ## Prime Numbers
 
 Write a function that identifies whether a given number is a prime number.
 
 A prime number is only divisible by **1** and itself, meaning it has no other divisors.
 
 1. Define a function named `isPrime(_:)` that accepts an integer.
 2.	Check if the number is prime by testing divisibility. A prime number has no divisors other than **1** and itself.
 3.	For simplicity, assume the input will be greater than 1.
 4.	Return `true` if the number is prime, otherwise `false`.
 
 > • Only check divisibility up to the square root of the number for efficiency.
 > • Use the modulus operator `%` to check for divisors.
 
 - Experiment: Extend the function to find all prime numbers within a given range.
 */
import Foundation
