/*:
 ## Decimal to Binary Conversion
 
 Write a function that converts a given decimal (base-10) integer into its binary (base-2) representation.
 
 The result should be returned as a string of 0s and 1s.
 
 1. Define a function named `decimalToBinary(_:)` that takes an integer as input.
 2. Use division by 2 to convert the decimal number into binary:
    - Repeatedly divide the number by 2, storing the remainders.
    - Reverse the order of the remainders to form the binary representation.
 3. Return the binary string.
 
 > • Use a loop to repeatedly divide the number by 2 and track the remainders.  
 > • Swift also has `String(number, radix: 2)`, but try implementing it manually first to practice the conversion logic.
 
 - Experiment: Create a function that performs the reverse operation, converting a binary string back to a decimal number.
 */
import Foundation
