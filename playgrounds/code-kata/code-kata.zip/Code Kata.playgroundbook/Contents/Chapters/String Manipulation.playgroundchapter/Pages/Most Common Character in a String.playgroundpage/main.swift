/*:#localized(key: "MostCommonCharacter")
 ## Most Common Character in a String
 
 **Goal:** Write a function that finds the most frequently occurring character in a given string.
 
 If there is a tie, return any one of the most common characters.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `mostCommonCharacter(_:)` that takes a string as input.
 2. Count the frequency of each character in the string.
 3. Identify and return the character with the highest frequency.
 
 * Callout(Extra challenge):
   Extend the function to return a list of the most common characters if there is a tie.
 */
import Foundation
