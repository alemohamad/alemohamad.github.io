/*:#localized(key: "ReversingStrings")
 ## Reversing Strings
 
 **Goal:** Write a function that reverses a given string.
 
 The function should return a new string with the characters in reverse order.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `reverseString(_:)` that takes a string as input.
 2. Reverse the characters in the string.
 3. Return the reversed string.
 
 * Callout(Extra challenge):
   Modify the function to ignore spaces and punctuation while reversing the main letters of the string.
 */
import Foundation
