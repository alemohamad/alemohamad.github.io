/*:
 ## Reversing Strings
 
 Write a function that reverses a given string.
 
 The function should return a new string with the characters in reverse order.
 
 1. Define a function named `reverseString(_:)` that takes a string as input.
 2. Reverse the characters in the string.
 3. Return the reversed string.
 
 > • You can use the `reversed()` method in Swift or create a loop to reverse the characters manually.  
 > • Ensure that spaces and punctuation are handled as normal characters.
 
 - Experiment: Modify the function to ignore spaces and punctuation while reversing the main letters of the string.
 */
import Foundation
