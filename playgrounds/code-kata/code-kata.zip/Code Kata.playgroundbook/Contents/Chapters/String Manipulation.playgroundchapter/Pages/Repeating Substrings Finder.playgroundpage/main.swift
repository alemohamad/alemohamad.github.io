/*:
 ## Repeating Substrings Finder
 
 Write a function that finds the first repeating substring in a given string.
 
 A repeating substring is defined as a sequence of characters that appears more than once in the string, consecutively or non-consecutively.
 
 1. Define a function named `findFirstRepeatingSubstring(_:)` that takes a string as input.
 2. Identify and return the first repeating substring found, or `nil` if no repeating substrings exist.
 3. Ensure that the search includes all possible substrings, starting with the smallest ones.
 
 > • Use nested loops to compare each substring with the rest of the string.  
 > • Consider using a `Set` to store substrings that have already been seen.
 
 - Experiment: Extend the function to return all repeating substrings in the order they appear.
 */
import Foundation
