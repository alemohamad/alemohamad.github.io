/*:
 ## Check for Balanced Parentheses
 
 Write a function that checks if a given string has balanced parentheses.
 
 Balanced parentheses mean that every opening parenthesis `(` has a corresponding closing parenthesis `)` in the correct order.
 
 1. Define a function named `isBalanced(_:)` that takes a string as input.
 2. Traverse the string to check for balanced parentheses:
    - Every `(` should have a matching `)`.
    - The closing `)` should not appear before its matching opening `(`.
 3. Return `true` if the string is balanced, otherwise `false`.
 
 > • Use a counter to keep track of open parentheses.  
 > • If you encounter a closing parenthesis `)` when there are no open parentheses to match, the string is unbalanced.
 
 - Experiment: Extend the function to check for balanced brackets `[]`, curly braces `{}`, and parentheses `()` in combination.
 */
import Foundation
