/*:#localized(key: "RemoveDuplicates")
 ## Remove Duplicates from String
 
 **Goal:** Write a function that removes duplicate characters from a given string, returning a new string that contains only unique characters in their first appearance order.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `removeDuplicates(_:)` that takes a string as input.
 2. Iterate through each character in the string, adding only unique characters to the result.
 3. Return the modified string with duplicates removed.
 
 * Callout(Extra challenge):
   Extend the function to ignore case, so A and a are considered duplicates.
 */
import Foundation
