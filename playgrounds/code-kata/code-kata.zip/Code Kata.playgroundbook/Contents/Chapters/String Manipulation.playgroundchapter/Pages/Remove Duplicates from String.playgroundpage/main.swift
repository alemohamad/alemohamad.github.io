/*:
 ## Remove Duplicates from String
 
 Write a function that removes duplicate characters from a given string, returning a new string that contains only unique characters in their first appearance order.
 
 1. Define a function named `removeDuplicates(_:)` that takes a string as input.
 2. Iterate through each character in the string, adding only unique characters to the result.
 3. Return the modified string with duplicates removed.
 
 > • Use a `Set` to track characters that have already been added.  
 > • Alternatively, use `filter` to create a new string with only unique characters.
 
 - Experiment: Extend the function to ignore case, so A and a are considered duplicates.
 */
import Foundation
