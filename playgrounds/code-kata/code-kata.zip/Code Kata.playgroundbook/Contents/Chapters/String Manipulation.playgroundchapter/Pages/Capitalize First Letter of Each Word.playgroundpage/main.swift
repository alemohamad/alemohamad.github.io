/*:#localized(key: "CapitalizeFirstLetter")
 ## Capitalize First Letter of Each Word
 
 **Goal:** Write a function that capitalizes the first letter of each word in a given string.
 
 Words are defined as sequences of characters separated by spaces.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `capitalizeWords(_:)` that takes a string as input.
 2. Split the string by spaces, capitalize the first letter of each word, and then rejoin the words with spaces.
 3. Return the newly formatted string.
 
 * Callout(Extra challenge):
   Extend the function to handle punctuation properly, ensuring only letters are capitalized.
 */
import Foundation
