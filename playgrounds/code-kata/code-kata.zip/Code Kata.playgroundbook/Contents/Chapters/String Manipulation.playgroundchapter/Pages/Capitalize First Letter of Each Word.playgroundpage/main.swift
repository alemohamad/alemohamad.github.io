/*:
 ## Capitalize First Letter of Each Word
 
 Write a function that capitalizes the first letter of each word in a given string.
 
 Words are defined as sequences of characters separated by spaces.
 
 1. Define a function named `capitalizeWords(_:)` that takes a string as input.
 2. Split the string by spaces, capitalize the first letter of each word, and then rejoin the words with spaces.
 3. Return the newly formatted string.
 
 > • Use `components(separatedBy: " ")` to split the string and `joined(separator: " ")` to reassemble it.  
 > • Use capitalized on each word to easily capitalize the first letter.
 
 - Experiment: Extend the function to handle punctuation properly, ensuring only letters are capitalized.
 */
import Foundation
