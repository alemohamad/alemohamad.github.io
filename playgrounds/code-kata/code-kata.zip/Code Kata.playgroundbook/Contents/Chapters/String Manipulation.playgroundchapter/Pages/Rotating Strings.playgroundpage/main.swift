/*:
 ## Rotating Strings
 
 Write a function that rotates the characters in a given string by a specified number of positions.
 
 Rotation means shifting characters to the right, with characters at the end wrapping around to the start.
 
 1. Define a function named `rotateString(_ by:)` that takes a string and an integer as input.
 2. Rotate the string by the specified number of positions:
    - If the rotation count is positive, shift characters to the right.
    - If the rotation count is negative, shift characters to the left.
 3. Return the rotated string.
 
 > • Use modular arithmetic to handle wraparounds.  
 > • Ensure the function handles cases where the rotation count is larger than the string length.
 
 - Experiment: Allow the function to handle multi-line strings and rotate each line independently.
 */
import Foundation
