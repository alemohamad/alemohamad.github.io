/*:#localized(key: "Anagrams")
 ## Anagrams Checker
 
 **Goal:** Write a function that checks whether two strings are anagrams.
 
 An anagram is a word or phrase formed by rearranging the letters of another, using all the original letters exactly once.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `areAnagrams(_:_:)` that takes two strings as input.
 2. Determine if the two strings contain the same characters in the same quantities.
 3. Return `true` if the strings are anagrams, otherwise `false`.
 
 * Callout(Extra challenge):
   Extend the function to check if a string is an anagram of a given list of words
 */
import Foundation
