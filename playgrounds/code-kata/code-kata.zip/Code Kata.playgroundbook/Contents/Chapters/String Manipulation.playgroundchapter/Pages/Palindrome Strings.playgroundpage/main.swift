/*:#localized(key: "Palindrome")
 ## Palindrome Strings
 
 **Goal:** Write a function that checks whether a given string is a palindrome.
 
 A palindrome is a word or phrase that reads the same forward and backward, ignoring spaces, punctuation, and case.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `isPalindrome(_:)` that takes a string as input.
 2. Remove spaces and punctuation, and convert the string to lowercase.
 3. Check if the modified string reads the same forward and backward.
 4. Return `true` if the string is a palindrome, otherwise `false`.
 
 * Callout(Extra challenge):
   Modify the function to handle multi-word phrases with spaces and punctuation correctly.
 */
import Foundation
