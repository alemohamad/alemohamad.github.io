/*:#localized(key: "Pangram")
 ## Pangram Checker
 
 **Goal:** Write a function that checks if a given string is a pangram.
 
 A pangram is a sentence that contains every letter of the alphabet at least once.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `isPangram(_:)` that takes a string as input.
 2. Convert the string to lowercase and check if it contains each letter from a to z.
 3. Return `true` if the string is a pangram, otherwise `false`.
 
 * Callout(Extra challenge):
   Extend the function to identify any missing letters if the string is not a pangram.
 */
import Foundation
