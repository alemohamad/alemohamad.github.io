/*:#localized(key: "LongestCommonPrefix")
 ## Longest Common Prefix
 
 **Goal:** Write a function that finds the longest common prefix among a list of strings.
 
 If there is no common prefix, the function should return an empty string.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `longestCommonPrefix(_:)` that takes an array of strings as input.
 2. Compare characters in each position across all strings to determine the longest shared prefix.
 3. Return the common prefix as a string.
 
 * Callout(Extra challenge):
   Allow the function to handle an empty array of strings without errors.
 */
import Foundation
