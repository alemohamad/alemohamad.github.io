/*:
 ## Character Frequency Counter
 
 Write a function that counts the frequency of each character in a given string, returning the result as a dictionary where each key is a character and its value is the frequency count.
 
 1. Define a function named `characterFrequency(_:)` that takes a string as input.
 2. Iterate through each character in the string, counting occurrences.
 3. Return a dictionary with characters as keys and their respective frequencies as values.
 
 > • Use a dictionary to store counts and update it as you iterate through the string.  
 > • Ensure that spaces, punctuation, and uppercase characters are handled appropriately if they should be counted.
 
 - Experiment: Modify the function to ignore case by converting all characters to lowercase before counting.
 */
import Foundation
