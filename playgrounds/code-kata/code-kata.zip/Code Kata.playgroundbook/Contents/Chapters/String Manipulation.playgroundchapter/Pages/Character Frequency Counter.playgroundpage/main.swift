/*:#localized(key: "CharacterFrequency")
 ## Character Frequency Counter
 
 **Goal:** Write a function that counts the frequency of each character in a given string, returning the result as a dictionary where each key is a character and its value is the frequency count.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `characterFrequency(_:)` that takes a string as input.
 2. Iterate through each character in the string, counting occurrences.
 3. Return a dictionary with characters as keys and their respective frequencies as values.
 
 * Callout(Extra challenge):
   Modify the function to ignore case by converting all characters to lowercase before counting.
 */
import Foundation
