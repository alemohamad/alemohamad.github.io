/*:
 ## Counting Words
 
 Write a function that counts the number of words in a given string.
 
 A word is defined as any sequence of characters separated by spaces.
 
 1. Define a function named `countWords(_:)` that takes a string as input.
 2. Split the string by spaces and count the number of resulting words.
 3. Return the word count as an integer.
 
 > • Use the `components(separatedBy:)` method to split the string by spaces.  
 > • Consider trimming leading and trailing spaces to ensure accurate counting.
 
 - Experiment: Extend the function to ignore punctuation and count only actual words.
 */
import Foundation
