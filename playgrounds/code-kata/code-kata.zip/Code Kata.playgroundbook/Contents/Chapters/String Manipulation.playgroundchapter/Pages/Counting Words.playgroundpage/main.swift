/*:#localized(key: "CountingWords")
 ## Counting Words
 
 **Goal:** Write a function that counts the number of words in a given string.
 
 A word is defined as any sequence of characters separated by spaces.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `countWords(_:)` that takes a string as input.
 2. Split the string by spaces and count the number of resulting words.
 3. Return the word count as an integer.
 
 * Callout(Extra challenge):
   Extend the function to ignore punctuation and count only actual words.
 */
import Foundation
