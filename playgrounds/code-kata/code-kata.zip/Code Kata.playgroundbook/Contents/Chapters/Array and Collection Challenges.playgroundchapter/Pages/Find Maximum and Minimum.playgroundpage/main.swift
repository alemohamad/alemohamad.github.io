/*:
 ## Find Maximum and Minimum
 
 Write a function that finds the maximum and minimum values in an array of integers, returning them as a tuple `(min, max)`.
 
 If the array is empty, return `nil`.
 
 1. Define a function named `findMinMax(_:)` that takes an array of integers as input.
 2. Identify and return the minimum and maximum values as a tuple.
 3. If the array is empty, return `nil`.
 
 > • Use the `min()` and `max()` methods, or iterate manually to find both values.  
 > • Ensure the function handles an empty array appropriately by returning `nil`.
 
 - Experiment: Modify the function to return the index positions of the minimum and maximum values in addition to the values themselves.
 */
import Foundation
