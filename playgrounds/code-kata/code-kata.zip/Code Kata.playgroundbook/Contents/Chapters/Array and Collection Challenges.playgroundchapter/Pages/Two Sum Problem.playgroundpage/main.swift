/*:#localized(key: "TwoSum")
 ## Two Sum Problem
 
 **Goal:** Write a function that finds two numbers in an array that add up to a specific target.
 
 The function should return the indices of the two numbers as a tuple.
 
 Assume each input has exactly one solution.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `twoSum(_:target:)` that takes an array of integers and a target integer as input.
 2. Identify two numbers in the array whose sum equals the target.
 3. Return the indices of the two numbers as a tuple.
 
 * Callout(Extra challenge):
   Modify the function to return all pairs of indices that sum up to the target, if there are multiple pairs.
 */
import Foundation
