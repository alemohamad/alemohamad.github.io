/*:
 ## Two Sum Problem
 
 Write a function that finds two numbers in an array that add up to a specific target.
 
 The function should return the indices of the two numbers as a tuple.
 
 Assume each input has exactly one solution.
 
 1. Define a function named `twoSum(_:target:)` that takes an array of integers and a target integer as input.
 2. Identify two numbers in the array whose sum equals the target.
 3. Return the indices of the two numbers as a tuple.
 
 > • Use a dictionary to store each number’s index as you iterate through the array.  
 > • For each element, check if the target minus the current number exists in the dictionary.
 
 - Experiment: Modify the function to return all pairs of indices that sum up to the target, if there are multiple pairs.
 */
import Foundation
