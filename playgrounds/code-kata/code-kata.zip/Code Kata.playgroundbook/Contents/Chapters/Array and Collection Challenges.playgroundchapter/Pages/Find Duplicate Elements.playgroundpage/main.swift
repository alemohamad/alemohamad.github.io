/*:
 ## Find Duplicate Elements
 
 Write a function that finds all duplicate elements in an array of integers and returns them as a set of unique values.
 
 1. Define a function named `findDuplicates(_:)` that takes an array of integers as input.
 2. Identify all elements that appear more than once.
 3. Return a set containing only the unique duplicate values.
 
 > • Use a `Set` to keep track of seen elements and another set for duplicates.  
 > • This method ensures that duplicates are stored as unique values.
 
 - Experiment: Modify the function to return the indices of each duplicate occurrence as well.
 */
import Foundation
