/*:#localized(key: "MatrixTranspose")
 ## Matrix Transpose
 
 **Goal:** Write a function that transposes a given matrix (2D array).
 
 Transposing a matrix means converting its rows into columns and its columns into rows.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `transposeMatrix(_:)` that takes a 2D array (array of arrays) as input.
 2. Convert the matrix so that rows become columns and columns become rows.
 3. Return the transposed matrix.
 
 * Callout(Extra challenge):
   Modify the function to handle matrices with non-integer values, such as `Double` or `String` matrices.
 */
import Foundation
