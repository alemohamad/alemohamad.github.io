/*:
 ## Find Intersection of Two Arrays
 
 Write a function that finds the intersection of two arrays, returning a new array with elements that appear in both arrays.
 
 Each element should appear only once in the result, even if it appears multiple times in the input arrays.
 
 1. Define a function named `findIntersection(_:_:)` that takes two arrays of integers as input.
 2. Identify and return the elements that appear in both arrays as a new array.
 3. Ensure that the resulting array contains only unique elements.
 
 > • Use a `Set` to track unique values in each array, then find the intersection.  
 > • Alternatively, use `filter` with `contains` to identify common elements.
 
 - Experiment: Extend the function to handle arrays of strings, finding common words or phrases between two lists.
 */
import Foundation
