/*:
 ## Sum of All Elements
 
 Write a function that calculates the sum of all elements in an array of integers.
 
 1. Define a function named `sumOfElements(_:)` that takes an array of integers as input.
 2. Calculate and return the sum of all integers in the array.
 
 > • Use the `reduce` method or a loop to sum the elements.  
 > • Ensure the function handles an empty array by returning `0` in that case.
 
 - Experiment: Modify the function to work with arrays of `Double` values as well as `Int`.
 */
import Foundation
