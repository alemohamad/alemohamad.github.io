/*:#localized(key: "SumElements")
 ## Sum of All Elements
 
 **Goal:** Write a function that calculates the sum of all elements in an array of integers.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `sumOfElements(_:)` that takes an array of integers as input.
 2. Calculate and return the sum of all integers in the array.
 
 * Callout(Extra challenge):
   Modify the function to work with arrays of `Double` values as well as `Int`.
 */
import Foundation
