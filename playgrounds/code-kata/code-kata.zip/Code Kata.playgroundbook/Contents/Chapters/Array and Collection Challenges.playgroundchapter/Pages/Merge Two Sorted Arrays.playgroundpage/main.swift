/*:#localized(key: "MergeSorted")
 ## Merge Two Sorted Arrays
 
 **Goal:** Write a function that merges two sorted arrays into a single sorted array.
 
 The resulting array should contain all elements from both input arrays in ascending order.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `mergeSortedArrays(_:_:)` that takes two sorted arrays of integers as input.
 2. Merge the arrays while maintaining the sorted order.
 3. Return the resulting sorted array.
 
 * Callout(Extra challenge):
   Modify the function to work with arrays of `Double` values, merging and sorting floating-point numbers.
 */
import Foundation
