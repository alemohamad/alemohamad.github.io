/*:
 ## Merge Two Sorted Arrays
 
 Write a function that merges two sorted arrays into a single sorted array.
 
 The resulting array should contain all elements from both input arrays in ascending order.
 
 1. Define a function named `mergeSortedArrays(_:_:)` that takes two sorted arrays of integers as input.
 2. Merge the arrays while maintaining the sorted order.
 3. Return the resulting sorted array.
 
 > • Use a two-pointer approach to merge the arrays efficiently.  
 > • Ensure that you handle cases where one array is longer than the other.
 
 - Experiment: Modify the function to work with arrays of `Double` values, merging and sorting floating-point numbers.
 */
import Foundation
