/*:#localized(key: "KthElement")
 ## Find Kth Largest Element
 
 **Goal:** Write a function that finds the Kth largest element in an unsorted array of integers.
 
 The Kth largest element is the element that would be in the Kth-to-last position if the array were sorted in descending order.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `findKthLargest(_ k:)` that takes an array of integers and an integer k as input.
 2. Return the Kth largest element in the array.
 
 * Callout(Extra challenge):
   Modify the function to find the Kth smallest element as well.
 */
import Foundation
