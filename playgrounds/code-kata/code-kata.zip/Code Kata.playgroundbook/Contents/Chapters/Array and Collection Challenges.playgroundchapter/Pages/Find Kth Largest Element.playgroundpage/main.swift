/*:
 ## Find Kth Largest Element
 
 Write a function that finds the Kth largest element in an unsorted array of integers.
 
 The Kth largest element is the element that would be in the Kth-to-last position if the array were sorted in descending order.
 
 1. Define a function named `findKthLargest(_ k:)` that takes an array of integers and an integer k as input.
 2. Return the Kth largest element in the array.
 
 > • Consider sorting the array and then accessing the Kth element from the end.  
 > • For a more efficient approach, use a min-heap or quickselect algorithm.
 
 - Experiment: Modify the function to find the Kth smallest element as well.
 */
import Foundation
