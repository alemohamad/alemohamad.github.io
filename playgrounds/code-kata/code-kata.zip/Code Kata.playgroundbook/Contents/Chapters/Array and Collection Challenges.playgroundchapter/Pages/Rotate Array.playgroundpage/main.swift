/*:
 ## Rotate Array
 
 Write a function that rotates an array of integers by a given number of positions.
 
 Rotation means shifting elements to the right, with elements at the end wrapping around to the beginning.
 
 1. Define a function named `rotateArray(_ by:)` that takes an array of integers and an integer as input.
 2. Rotate the array by the specified number of positions:
    - If the rotation count is positive, shift elements to the right.
    - If the rotation count is negative, shift elements to the left.
 3. Return the rotated array.
 
 > • Use modular arithmetic to handle wraparounds in the array.  
 > • Consider using array slicing to simplify the rotation.
 
 - Experiment: Extend the function to work with arrays of strings or floating-point numbers.
 */
import Foundation
