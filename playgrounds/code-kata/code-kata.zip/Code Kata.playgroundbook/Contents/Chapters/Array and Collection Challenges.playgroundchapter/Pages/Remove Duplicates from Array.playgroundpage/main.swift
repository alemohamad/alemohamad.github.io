/*:
 ## Remove Duplicates from Array
 
 Write a function that removes all duplicate elements from an array of integers, returning a new array that contains only unique values in their original order.
 
 1. Define a function named `removeDuplicates(_:)` that takes an array of integers as input.
 2. Iterate through the array, adding only unique values to the result.
 3. Return the new array with duplicates removed.
 
 > • Use a `Set` or check for containment to track and filter out duplicate values.  
 > • Preserve the original order of elements in the resulting array.
 
 - Experiment: Extend the function to handle arrays of strings, removing duplicate words or phrases.
 */
import Foundation
