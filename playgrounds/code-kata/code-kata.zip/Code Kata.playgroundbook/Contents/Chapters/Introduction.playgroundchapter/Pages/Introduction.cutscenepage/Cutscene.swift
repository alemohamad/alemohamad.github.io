import PlaygroundSupport
import SwiftUI

public extension Color {
    public static let background = Color(red: 254.0/255.0, green: 245.0/255.0, blue: 212.0/255.0)
    public static let birdOrange = Color(red: 231.0/255.0, green: 76.0/255.0, blue: 60.0/255.0)
}

struct ContentView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.background)
                .ignoresSafeArea()
            
            VStack(spacing: 36) {
                VStack(spacing: 16) {
                    Image(uiImage: UIImage(named: "katabird") ?? UIImage())
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                    VStack(spacing: 4) {
                        Text("Swift Code Kata")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        Text("コードカタ")
                            .font(.headline)
                            .fontWeight(.heavy)
                    }
                }
                
                VStack(spacing: 16) {
                    Text("A **code kata** is a programming exercise designed to be repeated regularly, helping developers sharpen their coding skills, improve problem-solving abilities, and deepen their understanding of language features. Inspired by martial arts practice, where “kata” refers to structured, repeated movements to build mastery, code katas focus on discipline, technique, and incremental improvement.")
                    Text("By practicing code katas in **Swift**, you’ll engage in a series of small, purposeful challenges that reinforce coding fundamentals, promote clean code habits, and encourage continuous growth in your craft.")
                }
                .frame(maxWidth: 720)
                
                Text("Begin your practice opening the list of katas at the top-left.")
                    .font(.footnote)
            }
            .foregroundStyle(Color.birdOrange)
            .padding(.horizontal, 24)
        }
    }
}

let swiftUIView = ContentView()
let hostingController = UIHostingController(rootView: swiftUIView)

PlaygroundPage.current.liveView = hostingController
// [next page](@next)
