/*:#localized(key: "SelectionSort")
 ## Selection Sort
 
 **Goal:** Write a function that sorts an array of integers in ascending order using the selection sort algorithm.
 
 Selection sort works by repeatedly finding the minimum element from the unsorted portion of the list and moving it to the sorted portion.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `bubbleSort(_:)` that takes an array of integers as input.
 2. Implement the bubble sort algorithm:
    - Repeatedly pass through the array.
    - For each pair of adjacent elements, swap them if they are in the wrong order.
 3. Return the sorted array.
 
 * Callout(Extra challenge):
   Modify the function to sort the array in descending order.
 */
import Foundation
