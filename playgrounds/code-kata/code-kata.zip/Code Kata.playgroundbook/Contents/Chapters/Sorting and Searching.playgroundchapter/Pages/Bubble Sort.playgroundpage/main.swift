/*:
 ## Bubble Sort
 
 Write a function that sorts an array of integers in ascending order using the bubble sort algorithm.
 
 Bubble sort works by repeatedly stepping through the list, comparing adjacent elements, and swapping them if they are in the wrong order.
 
 1. Define a function named `bubbleSort(_:)` that takes an array of integers as input.
 2. Implement the bubble sort algorithm:
    - Repeatedly pass through the array.
    - For each pair of adjacent elements, swap them if they are in the wrong order.
 3. Return the sorted array.
 
 > • Bubble sort has a time complexity of O(n²), so it may be slow for large arrays.  
 > • Use a flag to track whether a pass through the array made any swaps, allowing you to stop early if the array is already sorted.
 
 - Experiment: Optimize the function to avoid unnecessary comparisons by reducing the length of each pass through the array.
 */
import Foundation
