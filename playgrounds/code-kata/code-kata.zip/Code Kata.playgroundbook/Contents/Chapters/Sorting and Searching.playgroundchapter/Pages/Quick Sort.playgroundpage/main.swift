/*:
 ## Quick Sort
 
 Write a function that sorts an array of integers in ascending order using the quicksort algorithm.
 
 Quicksort is a divide-and-conquer algorithm that selects a “pivot” element, partitions the array into elements less than and greater than the pivot, and recursively sorts the partitions.
 
 1. Define a function named `quickSort(_:)` that takes an array of integers as input.
 2. Implement the quicksort algorithm:
    - If the array has one or no elements, it is already sorted.
    - Choose a pivot element (typically the last element or a random element).
    - Partition the array into elements less than the pivot and elements greater than the pivot.
    - Recursively apply quicksort to each partition and combine the results.
 3. Return the sorted array.
 
 > • Quicksort has an average time complexity of O(n log n) but can degrade to O(n²) in the worst case if the pivot selection is poor.  
 > • To improve performance, consider choosing a random pivot or using the median of three elements.
 
 - Experiment: Modify the function to sort the array in descending order.
 */
import Foundation
