/*:
 ## Find Closest Point in an Array of Coordinates
 
 Write a function that finds the point in an array of coordinates that is closest to a given target point.
 
 Use the Euclidean distance formula to determine the closest point.
 
 1. Define a function named `findClosestPoint(_:target:)` that takes an array of coordinates and a target coordinate as input.
 2. Calculate the Euclidean distance between each point in the array and the target point.
 3. Return the point in the array that has the smallest distance to the target.
 
 > • Use the formula `distance = sqrt((x2 - x1)^2 + (y2 - y1)^2)` to calculate each distance.  
 > • Track the minimum distance as you iterate through the array.
 
 - Experiment: Modify the function to return all points within a certain distance threshold from the target.
 */
import Foundation
