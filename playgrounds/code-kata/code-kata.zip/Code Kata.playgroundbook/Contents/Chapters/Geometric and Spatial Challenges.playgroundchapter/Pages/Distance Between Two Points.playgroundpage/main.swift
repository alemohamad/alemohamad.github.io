/*:
 ## Distance Between Two Points
 
 Write a function that calculates the Euclidean distance between two points in a 2D Cartesian plane.
 
 The distance is calculated using the distance formula.
 
 1. Define a function named `distanceBetweenPoints(_:_:)` that takes two coordinate pairs as input, where each coordinate pair is represented as a tuple `(x, y)`.
 2. Use the distance formula:
    - Calculate the difference between the x-coordinates and the y-coordinates.
    - Square both differences, add them, and take the square root of the result.
 3. Return the distance as a `Double`.
 
 > • Use the formula `distance = sqrt((x2 - x1)^2 + (y2 - y1)^2)`.  
 > • You can use Swift’s `sqrt` function from the `Foundation` library.
 
 - Experiment: Extend the function to calculate distances in a 3D space by adding a z-coordinate.
 */
import Foundation
