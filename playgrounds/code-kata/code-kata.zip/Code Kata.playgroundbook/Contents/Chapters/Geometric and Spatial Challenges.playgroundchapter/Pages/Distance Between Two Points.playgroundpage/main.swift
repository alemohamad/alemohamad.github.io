/*:#localized(key: "BetweenTwoPoints")
 ## Distance Between Two Points
 
 **Goal:** Write a function that calculates the Euclidean distance between two points in a 2D Cartesian plane.
 
 The distance is calculated using the distance formula.
 
 ---
 
 **Instructions:**
 
 1. Define a function named `distanceBetweenPoints(_:_:)` that takes two coordinate pairs as input, where each coordinate pair is represented as a tuple `(x, y)`.
 2. Use the distance formula:
    - Calculate the difference between the x-coordinates and the y-coordinates.
    - Square both differences, add them, and take the square root of the result.
 3. Return the distance as a `Double`.
 
 * Callout(Extra challenge):
   Extend the function to calculate distances in a 3D space by adding a z-coordinate.
 */
import Foundation
