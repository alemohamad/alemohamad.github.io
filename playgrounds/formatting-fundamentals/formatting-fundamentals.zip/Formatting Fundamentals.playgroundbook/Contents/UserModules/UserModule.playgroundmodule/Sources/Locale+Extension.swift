import Foundation

public extension Locale {
    static var americanEnglish: Locale { Locale(identifier: "en_US") }
    static var argentinianSpanish: Locale { Locale(identifier: "es_AR") }
    static var arabic: Locale { Locale(identifier: "ar_SA") }
    static var brazilianPortuguese: Locale { Locale(identifier: "pt_BR") }
    static var chinese: Locale { Locale(identifier: "zh_CN") }
    static var czech: Locale { Locale(identifier: "cs_CZ") }
    static var english: Locale { Locale(identifier: "en_UK") }
    static var french: Locale { Locale(identifier: "fr_FR") }
    static var german: Locale { Locale(identifier: "de_DE") }
    static var hebrew: Locale { Locale(identifier: "he_IL") }
    static var hindi: Locale { Locale(identifier: "hi_IN") }
    static var italian: Locale { Locale(identifier: "it_IT") }
    static var japanese: Locale { Locale(identifier: "ja_JP") }
    static var korean: Locale { Locale(identifier: "ko_KR") }
    static var portuguese: Locale { Locale(identifier: "pt_PT") }
    static var russian: Locale { Locale(identifier: "ru_RU") }
    static var spanish: Locale { Locale(identifier: "es_ES") }
    static var turkish: Locale { Locale(identifier: "tr_TR") }
}
