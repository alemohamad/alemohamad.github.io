import Foundation

public extension String {
    static var australianDollar: String { "AUD" }
    static var brazilianReal: String { "BRL" }
    static var britishPoundSterling: String { "GBP" }
    static var canadianDollar: String { "CAD" }
    static var chineseRenminbi: String { "CNY" }
    static var czechKoruna: String { "CZK" }
    static var euro: String { "EUR" }
    static var hongKongDollar: String { "HKD" }
    static var indianRupee: String { "INR" }
    static var israeliNewShekel: String { "ILS" }
    static var japaneseYen: String { "JPY" }
    static var mexicanPeso: String { "MXN" }
    static var russianRuble: String { "RUB" }
    static var southKoreanWon: String { "KRW" }
    static var swedishKrona: String { "SEK" }
    static var swissFranc: String { "CHF" }
    static var turkishLira: String { "TRY" }
    static var ukrainianHryvnia: String { "UAH" }
    static var unitedArabEmiratesDirham: String { "AED" }
    static var usDollar: String { "USD" }
}
