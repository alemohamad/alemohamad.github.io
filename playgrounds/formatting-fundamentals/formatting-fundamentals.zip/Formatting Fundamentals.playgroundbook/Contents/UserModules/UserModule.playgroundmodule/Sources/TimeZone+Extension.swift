import Foundation

public extension TimeZone {
    static var Berlin: TimeZone { TimeZone(identifier: "Europe/Berlin")! }
    static var BuenosAires: TimeZone { TimeZone(identifier: "America/Argentina/Buenos_Aires")! }
    static var Delhi: TimeZone { TimeZone(identifier: "Asia/Kolkata")! }
    static var Dubai: TimeZone { TimeZone(identifier: "Asia/Dubai")! } 
    static var Istanbul: TimeZone { TimeZone(identifier: "Europe/Istanbul")! } 
    static var Jerusalem: TimeZone { TimeZone(identifier: "Asia/Jerusalem")! }
    static var Lisbon: TimeZone { TimeZone(identifier: "Europe/Lisbon")! }
    static var London: TimeZone { TimeZone(identifier: "Europe/London")! }
    static var LosAngeles: TimeZone { TimeZone(identifier: "America/Los_Angeles")! }
    static var Madrid: TimeZone { TimeZone(identifier: "Europe/Madrid")! }
    static var Moscow: TimeZone { TimeZone(identifier: "Europe/Moscow")! }
    static var NewYork: TimeZone { TimeZone(identifier: "America/New_York")! }
    static var Paris: TimeZone { TimeZone(identifier: "Europe/Paris")! }
    static var Prague: TimeZone { TimeZone(identifier: "Europe/Prague")! }
    static var Rome: TimeZone { TimeZone(identifier: "Europe/Rome")! }
    static var SaoPaulo: TimeZone { TimeZone(identifier: "America/Sao_Paulo")! }
    static var Seoul: TimeZone { TimeZone(identifier: "Asia/Seoul")! }
    static var Shanghai: TimeZone { TimeZone(identifier: "Asia/Shanghai")! }
    static var Tokyo: TimeZone { TimeZone(identifier: "Asia/Tokyo")! }
}
