/*:
![Design Patterns](patterns-01.png)

# Structural Design Patterns

Structural design patterns explain how to assemble objects and classes into larger structures, while keeping these structures flexible and efficient.

## Adapter ★★★

Allows objects with incompatible interfaces to collaborate.

* [Main article →](https://refactoring.guru/design-patterns/adapter)
* [Conceptual example](Adapter%20Conceptual%20Example)
* [Real-world example](Adapter%20Real%20World%20Example)

## Bridge ★☆☆

Lets you split a large class or a set of closely related classes into two separate hierarchies—abstraction and implementation—which can be developed independently of each other.

* [Main article →](https://refactoring.guru/design-patterns/bridge)
* [Conceptual example](Bridge%20Conceptual%20Example)
* [Real-world example](Bridge%20Real%20World%20Example)

## Composite ★★☆

Lets you compose objects into tree structures and then work with these structures as if they were individual objects.

* [Main article →](https://refactoring.guru/design-patterns/composite)
* [Conceptual example](Composite%20Conceptual%20Example)
* [Real-world example](Composite%20Real%20World%20Example)

## Decorator ★★☆

Lets you attach new behaviors to objects by placing these objects inside special wrapper objects that contain the behaviors.

* [Main article →](https://refactoring.guru/design-patterns/decorator)
* [Conceptual example](Decorator%20Conceptual%20Example)
* [Real-world example](Decorator%20Real%20World%20Example)

## Facade ★★☆

Provides a simplified interface to a library, a framework, or any other complex set of classes.

* [Main article →](https://refactoring.guru/design-patterns/facade)
* [Conceptual example](Facade%20Conceptual%20Example)
* [Real-world example](Facade%20Real%20World%20Example)

## Flyweight ★☆☆

Lets you fit more objects into the available amount of RAM by sharing common parts of state between multiple objects instead of keeping all of the data in each object.

* [Main article →](https://refactoring.guru/design-patterns/flyweight)
* [Conceptual example](Flyweight%20Conceptual%20Example)
* [Real-world example](Flyweight%20Real%20World%20Example)

## Proxy ★☆☆

Lets you provide a substitute or placeholder for another object. A proxy controls access to the original object, allowing you to perform something either before or after the request gets through to the original object.

* [Main article →](https://refactoring.guru/design-patterns/proxy)
* [Conceptual example](Proxy%20Conceptual%20Example)
* [Real-world example](Proxy%20Real%20World%20Example)
 */
