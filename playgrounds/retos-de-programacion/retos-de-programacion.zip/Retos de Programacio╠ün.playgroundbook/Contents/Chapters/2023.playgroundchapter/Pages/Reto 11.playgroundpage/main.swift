/*:
 # Reto #11
 ## URL PARAMS

 > Fecha publicación enunciado: 13/03/23  
 > Fecha publicación resolución: 20/03/23  
 > Dificultad: FÁCIL

 Dada una URL con parámetros, crea una función que obtenga sus valores.
 
 No se pueden usar operaciones del lenguaje que realicen esta tarea directamente.
 
 Ejemplo: En la url [https://retosdeprogramacion.com?year=2023&challenge=0](https://retosdeprogramacion.com?year=2023&challenge=0)
 los parámetros serían ["2023", "0"]
 */
import Foundation

