/*:
 # Reto #12
 ## VIERNES 13

 > Fecha publicación enunciado: 20/03/23  
 > Fecha publicación resolución: 27/03/23  
 > Dificultad: FÁCIL

 Crea una función que sea capaz de detectar si existe un viernes 13
 en el mes y el año indicados.
 - La función recibirá el mes y el año y retornará verdadero o falso.
 */
import Foundation

func friday13(year: Int, month: Int) -> Bool {
    let calendar = Calendar(identifier: .gregorian)
    var components = DateComponents()
    components.year = year
    components.month = month
    components.day = 13

    if let date = calendar.date(from: components) {
        return calendar.component(.weekday, from: date) == 6
    }

    return false
}

print(friday13(year: 2023, month: 3))
print(friday13(year: 2023, month: 1))
print(friday13(year: 2023, month: 13))
print(friday13(year: -2023, month: 1))
print(friday13(year: 2023, month: 0))
