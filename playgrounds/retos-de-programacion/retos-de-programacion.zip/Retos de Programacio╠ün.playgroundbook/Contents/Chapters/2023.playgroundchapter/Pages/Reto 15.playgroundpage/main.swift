/*:
 # Reto #15
 ## AUREBESH

 > Fecha publicación enunciado: 10/04/23  
 > Fecha publicación resolución: 17/04/23  
 > Dificultad: FÁCIL

 Crea una función que sea capaz de transformar Español al lenguaje básico 
 del universo Star Wars: el "Aurebesh".
 - Puedes dejar sin transformar los caracteres que no existan en "Aurebesh".
 - También tiene que ser capaz de traducir en sentido contrario.
 
 ¿Lo has conseguido? Nómbrame en [twitter.com/mouredev](https://twitter.com/mouredev) y escríbeme algo en Aurebesh.
 
 ¡Que la fuerza os acompañe!
 */
import Foundation

