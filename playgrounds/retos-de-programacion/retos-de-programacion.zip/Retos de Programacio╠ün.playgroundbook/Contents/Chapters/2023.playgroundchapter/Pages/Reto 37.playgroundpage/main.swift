/*:
 # Reto #37
 ## COLORES HEX Y RGB

 > Fecha publicación enunciado: 18/09/23  
 > Fecha publicación resolución: 25/09/23  
 > Dificultad: MEDIA

 Crea las funciones capaces de transformar colores HEX
 a RGB y viceversa.
 
 Ejemplos:
 - RGB a HEX:  
   r: 0, g: 0, b: 0 -> #000000
 - HEX a RGB:  
   hex: #000000 -> (r: 0, g: 0, b: 0)
 */
import Foundation

