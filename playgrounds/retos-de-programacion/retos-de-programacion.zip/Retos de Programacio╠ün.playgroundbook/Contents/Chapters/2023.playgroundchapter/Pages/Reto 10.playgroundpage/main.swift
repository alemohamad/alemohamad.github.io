/*:
 # Reto #10
 ## LA API

 > Fecha publicación enunciado: 06/03/23  
 > Fecha publicación resolución: 13/03/23  
 > Dificultad: MEDIA

 Llamar a una API es una de las tareas más comunes en programación.
 
 Implementa una llamada HTTP a una API (la que tú quieras) y muestra su
 resultado a través de la terminal. Por ejemplo: Pokémon, Marvel...
 
 Aquí tienes un listado de posibles APIs:  
 [https://github.com/public-apis/public-apis](https://github.com/public-apis/public-apis)
 */
import Foundation
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true

struct PokemonList: Decodable {
    let results: [Pokemon]
}

struct Pokemon: Decodable {
    let name: String
}

if let url = URL(string: "https://pokeapi.co/api/v2/pokemon?limit=151") {
    let request = URLRequest(url: url)
    let (data, response) = try await URLSession.shared.data(for: request)

    if (response as? HTTPURLResponse)?.statusCode == 200 {
        let pokemonList = try JSONDecoder().decode(PokemonList.self, from: data)
        for (index, pokemon) in pokemonList.results.enumerated() {
            let pokemonName = pokemon.name
            print("#\(index + 1) \(pokemonName)")
        }

        page.finishExecution()
    }
}
