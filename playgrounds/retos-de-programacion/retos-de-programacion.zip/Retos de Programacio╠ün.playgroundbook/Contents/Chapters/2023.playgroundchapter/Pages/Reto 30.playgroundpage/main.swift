/*:
 # Reto #30
 ## EL TECLADO T9

 > Fecha publicación enunciado: 24/07/23  
 > Fecha publicación resolución: 31/07/23  
 > Dificultad: MEDIA

 Los primeros dispositivos móviles tenían un teclado llamado T9
 con el que se podía escribir texto utilizando únicamente su
 teclado numérico (del 0 al 9).
 
 Crea una función que transforme las pulsaciones del T9 a su
 representación con letras.
 - Debes buscar cuál era su correspondencia original.
 - Cada bloque de pulsaciones va separado por un guión.
 - Si un bloque tiene más de un número, debe ser siempre el mismo.
 - Ejemplo:
   - Entrada: 6-666-88-777-33-3-33-888
   - Salida: MOUREDEV
 */
import Foundation

