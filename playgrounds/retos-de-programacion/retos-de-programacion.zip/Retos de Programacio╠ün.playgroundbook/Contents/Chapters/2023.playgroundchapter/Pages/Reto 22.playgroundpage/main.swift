/*:
 # Reto #22
 ## LA ESPIRAL

 > Fecha publicación enunciado: 29/05/23  
 > Fecha publicación resolución: 06/06/23  
 > Dificultad: MEDIA

 Crea una función que dibuje una espiral como la del ejemplo.
 - Únicamente se indica de forma dinámica el tamaño del lado.
 - Símbolos permitidos: ═ ║ ╗ ╔ ╝ ╚
 
 Ejemplo espiral de lado 5 (5 filas y 5 columnas):

```
════╗
╔══╗║
║╔╗║║
║╚═╝║
╚═══╝
```
 */
import Foundation

