/*:
 # Reto #39
 ## TRIPLES PITAGÓRICOS

 > Fecha publicación enunciado: 02/10/23  
 > Fecha publicación resolución: 09/10/23  
 > Dificultad: MEDIA

 Crea una función que encuentre todos los triples pitagóricos
 (ternas) menores o iguales a un número dado.
 - Debes buscar información sobre qué es un triple pitagórico.
 - La función únicamente recibe el número máximo que puede
   aparecer en el triple.
 - Ejemplo: Los triples menores o iguales a 10 están
   formados por (3, 4, 5) y (6, 8, 10).
 */
import Foundation

