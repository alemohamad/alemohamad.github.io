/*:
 # Reto #3
 ## EL GENERADOR DE CONTRASEÑAS

 > Fecha publicación enunciado: 16/01/23  
 > Fecha publicación resolución: 23/01/23  
 > Dificultad: MEDIA

 Escribe un programa que sea capaz de generar contraseñas de forma aleatoria.

 Podrás configurar generar contraseñas con los siguientes parámetros:
 - Longitud: Entre 8 y 16.
 - Con o sin letras mayúsculas.
 - Con o sin números.
 - Con o sin símbolos.

 (Pudiendo combinar todos estos parámetros entre ellos)
 */
import Foundation

func passwordGenerator(length: Int = 8,
                       capital: Bool = false,
                       numbers: Bool = false,
                       symbols: Bool = false) -> String {

    // Fuente: https://www.ascii-code.com

    var characters = Array(97...122)

    if capital {
        characters += Array(65...90)
    }

    if numbers {
        characters += Array(48...57)
    }

    if symbols {
        characters += Array(33...47) + Array(58...64) + Array(91...96)
    }

    var password = ""

    let finalLength = length < 8 ? 8 : length > 16 ? 16 : length

    while password.count < finalLength {
        if let unicode = characters.randomElement(), let scalar = UnicodeScalar(unicode) {
            password += Character(scalar).description
        }
    }

    return password
}

print(passwordGenerator())
print(passwordGenerator(length: 16))
print(passwordGenerator(length: 1))
print(passwordGenerator(length: 22))
print(passwordGenerator(length: 12, capital: true))
print(passwordGenerator(length: 12, capital: true, numbers: true))
print(passwordGenerator(length: 12, capital: true, numbers: true, symbols: true))
print(passwordGenerator(length: 12, capital: true, symbols: true))
