/*:
 # Reto #24
 ## CIFRADO CÉSAR

 > Fecha publicación enunciado: 12/06/23  
 > Fecha publicación resolución: 19/06/23  
 > Dificultad: FÁCIL

 Crea un programa que realize el cifrado César de un texto y lo imprima.

 También debe ser capaz de descifrarlo cuando así se lo indiquemos.
 
 Te recomiendo que busques información para conocer en profundidad cómo
 realizar el cifrado. Esto también forma parte del reto.
 */
import Foundation

