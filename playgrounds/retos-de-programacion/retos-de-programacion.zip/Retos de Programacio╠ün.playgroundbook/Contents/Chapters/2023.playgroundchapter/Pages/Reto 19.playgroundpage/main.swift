/*:
 # Reto #19
 ## ANÁLISIS DE TEXTO

 > Fecha publicación enunciado: 11/05/23  
 > Fecha publicación resolución: 15/05/23  
 > Dificultad: MEDIA

 Crea un programa que analice texto y obtenga:
 - Número total de palabras.
 - Longitud media de las palabras.
 - Número de oraciones del texto (cada vez que aparecen un punto).
 - Encuentre la palabra más larga.
 
 Todo esto utilizando un único bucle.
 */
import Foundation

