/*:
 # Reto #21
 ## NÚMEROS PRIMOS GEMELOS

 > Fecha publicación enunciado: 22/05/23  
 > Fecha publicación resolución: 29/05/23  
 > Dificultad: MEDIA

 Crea un programa que encuentre y muestre todos los pares de números primos
 gemelos en un rango concreto.
 
 El programa recibirá el rango máximo como número entero positivo.
 
 - Un par de números primos se considera gemelo si la diferencia entre
   ellos es exactamente 2. Por ejemplo (3, 5), (11, 13)
 
 - Ejemplo: Rango 14  
   (3, 5), (5, 7), (11, 13)
 */
import Foundation

