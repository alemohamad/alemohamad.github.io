/*:
 # Reto #41
 ## LA CASA ENCANTADA

 > Fecha publicación enunciado: 16/10/23  
 > Fecha publicación resolución: 23/10/23  
 > Dificultad: DIFÍCIL

 Este es un reto especial por Halloween.
 
 Te encuentras explorando una mansión abandonada llena de habitaciones.
 
 En cada habitación tendrás que resolver un acertijo para poder avanzar a la siguiente.
 
 Tu misión es encontrar la habitación de los dulces.
 
 Se trata de implementar un juego interactivo de preguntas y respuestas por terminal.  
 (Tienes total libertad para ser creativo con los textos)
 
 - 🏰 Casa: La mansión se corresponde con una estructura cuadrada 4 x 4
   que deberás modelar. Las habitaciones de puerta y dulces no tienen enigma.
   (16 habitaciones, siendo una de entrada y otra donde están los dulces)
 
   Esta podría ser una representación:
```
  🚪⬜️⬜️⬜️
  ⬜️👻⬜️⬜️
  ⬜️⬜️⬜️👻
  ⬜️⬜️🍭⬜️
```

 - ❓ Enigmas: Cada habitación propone un enigma aleatorio que deberás responder con texto.  
   Si no lo aciertas no podrás desplazarte.
 - 🧭 Movimiento: Si resuelves el enigma se te preguntará a donde quieres desplazarte.  
   (Ejemplo: norte/sur/este/oeste. Sólo deben proporcionarse las opciones posibles)
 - 🍭 Salida: Sales de la casa si encuentras la habitación de los dulces.
 - 👻 (Bonus) Fantasmas: Existe un 10% de que en una habitación aparezca un fantasma y
   tengas que responder dos preguntas para salir de ella.
 */
import Foundation

