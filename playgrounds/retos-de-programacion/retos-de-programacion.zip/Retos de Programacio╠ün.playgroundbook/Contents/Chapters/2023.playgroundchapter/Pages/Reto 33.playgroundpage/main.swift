/*:
 # Reto #31
 ## TETRIS

 > Fecha publicación enunciado: 07/08/23  
 > Fecha publicación resolución: 14/08/23  
 > Dificultad: MEDIA

 Crea un programa capaz de gestionar una pieza de Tetris.
 - La pantalla de juego tiene 10 filas y 10 columnas representadas por símbolos 🔲
 - La pieza de tetris a manejar será la siguiente (si quieres, puedes elegir otra):
```
   🔳
   🔳🔳🔳
```
 - La pieza aparecerá por primera vez en la parte superior izquierda de la pantalla de juego.
```
  🔳🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔳🔳🔳🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
  🔲🔲🔲🔲🔲🔲🔲🔲🔲🔲
```

 - Debes desarrollar una función capaz de desplazar y rotar la pieza en el tablero,
   recibiendo una acción cada vez que se llame, mostrando cómo se visualiza en la pantalla de juego.
 - Las acciones que se pueden aplicar a la pieza son: derecha, izquierda, abajo, rotar.
 - Debes tener en cuenta los límites de la pantalla de juego.
 */
import Foundation
