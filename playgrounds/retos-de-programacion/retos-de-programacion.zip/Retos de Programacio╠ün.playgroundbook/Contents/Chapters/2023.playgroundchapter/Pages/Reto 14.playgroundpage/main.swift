/*:
 # Reto #14
 ## OCTAL Y HEXADECIMAL

 > Fecha publicación enunciado: 03/04/23  
 > Fecha publicación resolución: 10/04/23  
 > Dificultad: FÁCIL

 Crea una función que reciba un número decimal y lo trasforme a Octal
 y Hexadecimal.
 - No está permitido usar funciones propias del lenguaje de programación que
   realicen esas operaciones directamente.
 */
import Foundation

