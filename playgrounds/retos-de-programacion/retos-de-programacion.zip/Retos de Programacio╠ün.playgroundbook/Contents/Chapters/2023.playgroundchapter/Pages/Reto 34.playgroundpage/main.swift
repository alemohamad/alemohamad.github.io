/*:
 # Reto #34
 ## EL TXT

 > Fecha publicación enunciado: 21/08/23  
 > Fecha publicación resolución: 28/08/23  
 > Dificultad: MEDIA

 Crea un programa capaz de interactuar con un fichero TXT.
 
 **IMPORTANTE:** El fichero TXT NO debe subirse como parte de la corrección. 
 Únicamente el código.
 
 - Si no existe, debe crear un fichero llamado "text.txt".
 - Desde el programa debes ser capaz de introducir texto por consola y guardarlo
   en una nueva línea cada vez que se pulse el botón "Enter".
 - Si el fichero existe, el programa tiene que dar la opción de seguir escribiendo
   a continuación o borrar su contenido y comenzar desde el principio.
 - Si se selecciona continuar escribiendo, se tiene que mostrar por consola
   el texto que ya posee el fichero.
 */
import Foundation

