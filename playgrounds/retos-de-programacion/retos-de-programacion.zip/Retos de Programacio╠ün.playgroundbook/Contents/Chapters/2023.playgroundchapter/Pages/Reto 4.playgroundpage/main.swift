/*:
 # Reto #4
 ## PRIMO, FIBONACCI Y PAR

 > Fecha publicación enunciado: 23/01/23  
 > Fecha publicación resolución: 30/01/23  
 > Dificultad: MEDIA

 Escribe un programa que, dado un número, compruebe y muestre si es primo,
 fibonacci y par.
 
 Ejemplos:
 - Con el número 2, nos dirá: "2 es primo, fibonacci y es par"
 - Con el número 7, nos dirá: "7 es primo, no es fibonacci y es impar"
 */
import Foundation

func fizzbuzz() {
    for number in 1...100 {
        if number % 3 == 0 && number % 5 == 0 {
            print("fizzbuzz")
        } else if number % 3 == 0 {
            print("fizz")
        } else if number % 5 == 0 {
            print("buzz")
        } else {
            print(number)
        }
    }
}

fizzbuzz()
