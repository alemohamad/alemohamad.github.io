/*:
 # Reto #7
 ## EL SOMBRERO SELECCIONADOR

 > Fecha publicación enunciado: 13/02/23  
 > Fecha publicación resolución: 20/02/23  
 > Dificultad: MEDIA

 Crea un programa que simule el comportamiento del sombrero selccionador del
 universo mágico de Harry Potter.
 - De ser posible realizará 5 preguntas (como mínimo) a través de la terminal.
 - Cada pregunta tendrá 4 respuestas posibles (también a selecciona una a través de terminal).
 - En función de las respuestas a las 5 preguntas deberás diseñar un algoritmo que
   coloque al alumno en una de las 4 casas de Hogwarts:  
   (Gryffindor, Slytherin , Hufflepuff y Ravenclaw)
 - Ten en cuenta los rasgos de cada casa para hacer las preguntas
   y crear el algoritmo seleccionador:  
   Por ejemplo, en Slytherin se premia la ambición y la astucia.
 */
import Foundation

