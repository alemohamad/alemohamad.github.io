/*:
 # Reto #9
 ## HETEROGRAMA, ISOGRAMA Y PANGRAMA

 > Fecha publicación enunciado: 27/02/23  
 > Fecha publicación resolución: 06/03/23  
 > Dificultad: FÁCIL

 Crea 3 funciones, cada una encargada de detectar si una cadena de
 texto es un heterograma, un isograma o un pangrama.
 - Debes buscar la definición de cada uno de estos términos.
 */
import Foundation

