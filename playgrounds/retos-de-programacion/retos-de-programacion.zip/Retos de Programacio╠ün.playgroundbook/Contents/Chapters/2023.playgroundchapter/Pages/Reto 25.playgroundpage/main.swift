/*:
 # Reto #25
 ## EL CÓDIGO KONAMI

 > Fecha publicación enunciado: 19/06/23  
 > Fecha publicación resolución: 26/06/23  
 > Dificultad: MEDIA

 Crea un programa que detecte cuando el famoso "Código Konami" se ha 
 introducido correctamente desde el teclado. 
 
 Si sucede esto, debe notificarse mostrando un mensaje en la terminal.
 */
import Foundation

