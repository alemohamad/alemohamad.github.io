/*:
 # Reto #8
 ## EL GENERADOR PSEUDOALEATORIO

 > Fecha publicación enunciado: 20/02/23  
 > Fecha publicación resolución: 27/02/23  
 > Dificultad: MEDIA

 Crea un generador de números pseudoaleatorios entre 0 y 100.
 - No puedes usar ninguna función "random" (o semejante) del 
   lenguaje de programación seleccionado.
 
 Es más complicado de lo que parece...
 */
import Foundation

func random() -> Int {
    return Calendar.current.component(.nanosecond, from: Date()) % 101
}

(0...100).forEach { _ in
    print(random())
}
