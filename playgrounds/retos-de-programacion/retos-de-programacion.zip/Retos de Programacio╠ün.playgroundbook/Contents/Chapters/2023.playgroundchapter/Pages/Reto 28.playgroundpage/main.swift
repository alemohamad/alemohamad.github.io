/*:
 # Reto #28
 ## EXPRESIÓN MATEMÁTICA

 > Fecha publicación enunciado: 10/07/23  
 > Fecha publicación resolución: 17/07/23  
 > Dificultad: MEDIA

 Crea una función que reciba una expresión matemática (String)
 y compruebe si es correcta. Retornará true o false.
 - Para que una expresión matemática sea correcta debe poseer
   un número, una operación y otro número separados por espacios.  
   Tantos números y operaciones como queramos.
 - Números positivos, negativos, enteros o decimales.
 - Operaciones soportadas: + - * / % 
 
 Ejemplos:
 - "5 + 6 / 7 - 4" -> true
 - "5 a 6" -> false
 */
import Foundation

