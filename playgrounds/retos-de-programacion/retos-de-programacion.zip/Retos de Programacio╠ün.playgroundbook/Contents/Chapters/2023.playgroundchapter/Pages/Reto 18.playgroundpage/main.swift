/*:
 # Reto #18
 ## WEB SCRAPING

 > Fecha publicación enunciado: 01/05/23  
 > Fecha publicación resolución: 11/05/23  
 > Dificultad: DIFÍCIL

 El día 128 del año celebramos en la comunidad el "Hola Mundo day"

 Vamos a hacer "web scraping" sobre su sitio web: [https://holamundo.day](https://holamundo.day)
 
 Crea un programa que se conecte a la web del evento e imprima únicamente la agenda de eventos
 del día 8. Mostrando hora e información de cada uno.
 
 Ejemplo: "16:00 | Bienvenida"
 
 Se permite utilizar librerías que nos faciliten esta tarea.
 */
import Foundation

