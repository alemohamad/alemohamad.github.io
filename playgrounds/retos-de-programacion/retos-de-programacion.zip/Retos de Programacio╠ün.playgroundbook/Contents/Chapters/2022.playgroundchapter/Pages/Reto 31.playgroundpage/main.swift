/*:
 # Reto #31
 ## AÑOS BISIESTOS

 > Fecha publicación enunciado: 01/08/22  
 > Fecha publicación resolución: 08/08/22  
 > Dificultad: FÁCIL

 Crea una función que imprima los 30 próximos años bisiestos
 siguientes a uno dado.
 - Utiliza el menor número de líneas para resolver el ejercicio.
 */
import Foundation

func thirtyLeapYears(year: Int) {
    var currentYear = year + 1
    var yearCount = 0

    while yearCount < 30 {
        if currentYear % 4 == 0 && (currentYear % 100 != 0 || currentYear % 400 == 0) {
            print(currentYear)
            yearCount += 1
        }

        currentYear += 1
    }
}

thirtyLeapYears(year: 1999)
thirtyLeapYears(year: -500)
