/*:
 # Reto #51
 ## EL RETO RANDOM

 > Fecha publicación enunciado: 19/12/22  
 > Fecha publicación resolución: 26/12/22  
 > Dificultad: ?

 Crea tu propio enunciado para que forme parte de los retos de 2023.
 - Ten en cuenta que su dificultad debe ser asumible por la comunidad y
   seguir un estilo semejante a los que hemos realizado durante el año.
 - Si quieres también puedes proponer tu propia solución al reto (en el
   lenguaje que quieras).
 */
import Foundation

