/*:
 # Reto #22
 ## CONJUNTOS

 > Fecha publicación enunciado: 01/06/22  
 > Fecha publicación resolución: 07/06/22  
 > Dificultad: FÁCIL

 Crea una función que reciba dos array, un booleano y retorne un array.
 - Si el booleano es verdadero buscará y retornará los elementos comunes
   de los dos array.
 - Si el booleano es falso buscará y retornará los elementos no comunes
   de los dos array.
 - No se pueden utilizar operaciones del lenguaje que
   lo resuelvan directamente.
 */
import Foundation

func calculateSet(first: [Int], second: [Int], common: Bool) -> [Int] {
    var commonResult: [Int] = []

    for firstValue in first {
        if !commonResult.contains(firstValue) {
            for secondValue in second {
                if firstValue == secondValue && !commonResult.contains(firstValue) {
                    commonResult.append(firstValue)
                    break
                }
            }
        }
    }

    if common {
        return commonResult
    } else {
        var nonCommonResult: [Int] = []
        nonCommonResult.append(contentsOf: first)
        nonCommonResult.append(contentsOf: second)

        commonResult.forEach { commonValue in
            nonCommonResult.removeAll { nonCommonValue in
                return commonValue == nonCommonValue
            }
        }

        return nonCommonResult
    }
}

print(calculateSet(first: [1, 2, 3, 3, 4], second: [2, 2, 3, 3, 3, 4, 6], common: true))
print(calculateSet(first: [1, 2, 3, 3, 4], second: [2, 2, 3, 3, 3, 4, 6], common: false))
