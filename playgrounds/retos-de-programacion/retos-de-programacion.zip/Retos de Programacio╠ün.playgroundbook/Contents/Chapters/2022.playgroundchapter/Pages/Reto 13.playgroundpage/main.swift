/*:
 # Reto #13
 ## FACTORIAL RECURSIVO

 > Fecha publicación enunciado: 28/03/22  
 > Fecha publicación resolución: 04/04/22  
 > Dificultad: FÁCIL

 Escribe una función que calcule y retorne el factorial de un número dado
 de forma recursiva.
 */
import Foundation

func factorial(n: Int) -> Int? {
    return n < 0 ? nil : n <= 1 ? 1 : n * (factorial(n: n - 1)!)
}

print(factorial(n: 0) ?? "No tiene factorial")
print(factorial(n: 7) ?? "No tiene factorial")
print(factorial(n: 10) ?? "No tiene factorial")
print(factorial(n: 1) ?? "No tiene factorial")
print(factorial(n: -1) ?? "No tiene factorial")
