/*:
 # Reto #14
 ## ¿ES UN NÚMERO DE ARMSTRONG?

 > Fecha publicación enunciado: 04/04/22  
 > Fecha publicación resolución: 11/04/22  
 > Dificultad: FÁCIL

 Escribe una función que calcule si un número dado es un número de Armstrong
 (o también llamado narcisista).  
 Si no conoces qué es un número de Armstrong, debes buscar información 
 al respecto.
 */
import Foundation

func isArmstrong(number: Int) -> Bool {
    if number < 0 {
        return false
    }

    var sum = 0
    let powValue = Double(number.description.count)

    number.description.forEach { character in
        sum += Int(pow(Double(character.description) ?? 0, powValue))
    }

    return number == sum
}

print(isArmstrong(number: 371))
print(isArmstrong(number: -371))
print(isArmstrong(number: 372))
print(isArmstrong(number: 0))
