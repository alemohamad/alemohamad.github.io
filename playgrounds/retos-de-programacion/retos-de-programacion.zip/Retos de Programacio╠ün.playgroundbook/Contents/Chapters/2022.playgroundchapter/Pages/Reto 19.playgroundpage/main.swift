/*:
 # Reto #19
 ## CONVERSOR TIEMPO

 > Fecha publicación enunciado: 09/05/22  
 > Fecha publicación resolución: 16/05/22  
 > Dificultad: FACIL

 Crea una función que reciba días, horas, minutos y segundos (como enteros)
 y retorne su resultado en milisegundos.
 */
import Foundation

func timeToMillis(days: Int, hours: Int, minutes: Int, seconds: Int) -> Int {
    let daysInMillis = days * 24 * 60 * 60 * 1000
    let hoursInMillis = hours * 60 * 60 * 1000
    let minutesInMillis = minutes * 60 * 1000
    let secondsToMillis = seconds * 1000

    return daysInMillis + hoursInMillis + minutesInMillis + secondsToMillis
}

print(timeToMillis(days: 0, hours: 0, minutes: 0, seconds: 10))
print(timeToMillis(days: 2, hours: 5, minutes: -45, seconds: 10))
print(timeToMillis(days: 2000000000, hours: 5, minutes: 45, seconds: 10))
