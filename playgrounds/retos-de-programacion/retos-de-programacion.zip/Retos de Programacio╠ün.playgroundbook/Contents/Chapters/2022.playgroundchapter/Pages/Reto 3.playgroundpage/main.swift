/*:
 # Reto #3
 ## ¿ES UN NÚMERO PRIMO?

 > Fecha publicación enunciado: 17/01/22  
 > Fecha publicación resolución: 24/01/22  
 > Dificultad: MEDIA

 Escribe un programa que se encargue de comprobar si un número es o no primo.  
 Hecho esto, imprime los números primos entre 1 y 100.
 */
import Foundation

func isPrime(number: Int) -> Bool {
    if number < 2 {
        return false
    }

    for i in 2 ..< number {
        if number % i == 0 {
            return false
        }
    }

    return true
}

(1...100).forEach { number in
    if isPrime(number: number) {
        print(number)
    }
}
