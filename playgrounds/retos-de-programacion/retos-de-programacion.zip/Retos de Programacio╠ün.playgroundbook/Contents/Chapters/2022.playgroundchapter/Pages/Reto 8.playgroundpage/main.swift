/*:
 # Reto #8
 ## DECIMAL A BINARIO

 > Fecha publicación enunciado: 18/02/22  
 > Fecha publicación resolución: 02/03/22  
 > Dificultad: FÁCIL

 Crea un programa se encargue de transformar un número
 decimal a binario sin utilizar funciones propias del lenguaje que lo hagan directamente.
 */
import Foundation

func decimalToBinary(_ decimal: Int) -> String {
    var number = decimal
    var binary = ""

    while number != 0 {
        let reminder = number % 2
        number /= 2

        binary = "\(reminder)\(binary)"
    }

    return binary.isEmpty ? "0" : binary
}

print(decimalToBinary(387))
print(decimalToBinary(0))
