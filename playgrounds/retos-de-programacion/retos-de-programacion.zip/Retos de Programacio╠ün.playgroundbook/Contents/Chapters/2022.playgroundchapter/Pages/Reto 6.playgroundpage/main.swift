/*:
 # Reto #6
 ## INVIRTIENDO CADENAS

 > Fecha publicación enunciado: 07/02/22  
 > Fecha publicación resolución: 14/02/22  
 > Dificultad: FÁCIL

 Crea un programa que invierta el orden de una cadena de texto
 sin usar funciones propias del lenguaje que lo hagan de forma automática.
 - Si le pasamos "Hola mundo" nos retornaría "odnum aloH"
 */
import Foundation

print(reverse(text: "Hola mundo"))
print(recursiveReverse(text: "Hola mundo"))

func reverse(text: String) -> String {
    let textCount = text.count - 1
    var reversedText = ""
    let textArray = Array(text)
    for index in 0...textCount {
        reversedText += "\(textArray[textCount - index])"
    }
    return reversedText
}

// Sin un bucle, mediante una función recursiva
func recursiveReverse(text: String, index: Int = 0, reversedText: String = "") -> String {
    let textCount = text.count - 1
    var newReversedText = reversedText
    let textArray = Array(text)
    newReversedText += "\(textArray[textCount - index])"
    if index < textCount {
        let newIndex = index + 1
        newReversedText = recursiveReverse(text: text, index:newIndex, reversedText: newReversedText)
    }
    return newReversedText
}
