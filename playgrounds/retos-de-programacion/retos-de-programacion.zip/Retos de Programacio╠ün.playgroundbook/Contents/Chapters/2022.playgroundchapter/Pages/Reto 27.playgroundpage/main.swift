/*:
 # Reto #27
 ## VECTORES ORTOGONALES

 > Fecha publicación enunciado: 07/07/22  
 > Fecha publicación resolución: 11/07/22  
 > Dificultad: FÁCIL

 Crea un programa que determine si dos vectores son ortogonales.

 - Los dos array deben tener la misma longitud.
 - Cada vector se podría representar como un array. Ejemplo: [1, -2]
 */
import Foundation

func areOrthogonal(vectorOne: (first: Int, second: Int), vectorTwo: (first: Int, second: Int)) -> Bool {
    return vectorOne.first * vectorTwo.first + vectorOne.second * vectorTwo.second == 0
}

print(areOrthogonal(vectorOne: (first: 1, second: 2), vectorTwo: (first: 2, second: 1)))
print(areOrthogonal(vectorOne: (first: 2, second: 1), vectorTwo: (first: -1, second: 2)))
