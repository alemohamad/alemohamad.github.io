/*:
 # Reto #10
 ## EXPRESIONES EQUILIBRADAS

 > Fecha publicación enunciado: 07/03/22  
 > Fecha publicación resolución: 14/03/22  
 > Dificultad: MEDIA

 Crea un programa que comprueba si los paréntesis, llaves y corchetes
 de una expresión están equilibrados.
 - Equilibrado significa que estos delimitadores se abren y cieran
   en orden y de forma correcta.
 - Paréntesis, llaves y corchetes son igual de prioritarios.
   No hay uno más importante que otro.
 - Expresión balanceada: `{ [ a * ( c + d ) ] - 5 }`
 - Expresión no balanceada: `{ a * ( c + d ) ] - 5 }`
 */
import Foundation

print(isBalanced(expression: "{a + b [c] * (2x2)}}}}"))
print(isBalanced(expression: "{ [ a * ( c + d ) ] - 5 }"))
print(isBalanced(expression: "{ a * ( c + d ) ] - 5 }"))
print(isBalanced(expression: "{a^4 + (((ax4)}"))
print(isBalanced(expression: "{ ] a * ( c + d ) + ( 2 - 3 )[ - 5 }"))
print(isBalanced(expression: "{{{{{{(}}}}}}"))
print(isBalanced(expression: "(a"))

func isBalanced(expression: String) -> Bool {
    let symbols = ["{":"}", "[":"]", "(":")"]
    var stack = [String]()

    for character in expression {
        let symbol = character.description
        let containsKey = symbols.keys.contains(symbol)

        if containsKey || symbols.values.contains(symbol) {
            if containsKey {
                stack.append(symbol)
            } else if stack.isEmpty || symbol != symbols[stack.popLast() ?? ""] {
                return false
            }
        }
    }

    return stack.isEmpty
}
