/*:
 # Hola, ¿qué tal?
 
 Soy Alejandro, apasionado del ecosistema de Apple y del lenguaje Swift.
 
 He compilado en este Playground Book una serie de retos presentados por Brais Moure. Encontrarás soluciones a estos desafíos, muchas cortesía de Brais. Los desafíos más recientes no poseen solución, pero voy a estar actualizando este proyecto con soluciones propias a modo de contribuir a la comunidad.
 
 Este libro está pensado para ser un recurso práctico para que puedas fortalecer tus habilidades en programación y prepararte para los tipos de problemas que podrías enfrentar en entrevistas técnicas. ¡Todo accesible desde tu iPad!
 
 Espero que este material te sea de gran ayuda. Siéntente libre de contactarme con tus comentarios, correcciones o cualquier otra contribución que desees hacer en [@alemohamad](https://twitter.com/alemohamad).
 
 **Happy Swift coding!**
 
 ![Ale Mohamad](am-kit.png)
 */
