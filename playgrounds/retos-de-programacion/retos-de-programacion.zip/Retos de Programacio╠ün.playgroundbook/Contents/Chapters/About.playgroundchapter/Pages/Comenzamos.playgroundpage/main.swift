/*:
 # { Retos de Programación }

 > Mejora tus habilidades en [retosdeprogramacion.com](https://retosdeprogramacion.com).

 Ejercicios para mejorar tu **lógica de programación** y desarrollo de
 aplicaciones para añadir a tu **portfolio personal**.

 - Totalmente gratis y a tu ritmo
 - Basados en pruebas técnicas y entrevistas de trabajo
 - Usa el lenguaje de programación y tecnología que quieras
 - En constante actualización
 - Corrección y revisión en directo
 - Con el apoyo de la comunidad
 - Gana premios

 ***

 ***

 ## Preguntas Frecuentes

 > He creado un [vídeo](https://www.youtube.com/watch?v=8HuQXzJl_1I) para contarte cómo funciona retosdeprogramacion.com

 ### ¿Qué conocimientos necesito para participar?
 
 Los ejercicios semanales se resuelven en pocas líneas de código por lo que el
 conocimiento mínimo para abordarlos será menor que en las aplicaciones mensuales,
 ya que estas últimas cubren funcionalidades reales completas.  
 **¿Crees que no estás preparado?** No te preocupes. Intenta llevar a cabo los
 ejercicios. Se trata de aprender y mejorar poco a poco, no de hacerlos perfectos o
 completos a la primera.

 ### Acabo de llegar. ¿Debo realizar los retos anteriores?
 
 Cada ejercicio semanal y mensual es independiente del anterior. Cuanto más
 ejercicios resuelvas, mejor.  
 Dispondrás de correcciones y propuestas de resolución de todos los retos pasados,
 pudiendo realizar el seguimiento en comunidad de los últimos publicados mediante
 la transmisión en directo en [Twitch](https://twitch.tv/mouredev).

 ### ¿Cómo funcionan transmisiones en directo?
 
 Cada ejercicio posee una fecha de publicación y corrección (asegúrate de
 consultarla). El día indicado (habitualmente a las 20:00 hora España) realizaré
 una transmisión en directo desde [Twitch](https://twitch.tv/mouredev) para corregir y comentar el reto.  
 **¿Y si me pierdo el directo?** No te preocupes. Puedes consultar transmisiones
 pasadas de hasta 60 días en la sección [vídeos de Twitch](https://www.twitch.tv/mouredev/videos). No olvides que todas las
 correcciones están disponibles en el repositorio de GitHub correspondiente a cada
 tipo de reto mensual y semanal.

 ### ¿Puedo usar cualquier lenguaje de programación?
 
 Por supuesto. Los ejercicios semanales están pensados para que puedan ser
 resueltos con la mayoría de lenguajes de programación actuales. Para las
 aplicaciones mensuales podrás elegir entre Web o app iOS y Android. Se trata de
 que uses la tecnología que creas que más te va a beneficiar.

 ### ¿Cómo puedo participar?

 En la web correspondiente a retos [mensuales](https://retosdeprogramacion.com/mensuales2022) y
 [semanales](https://retosdeprogramacion.com/semanales2023) encontrarás todas las
 instrucciones y preguntas frecuentes, así como el enlace al repositorio de GitHub
 con enunciados y resoluciones de cada reto.

 ***

 ***

 ## Hola, mi nombre es Brais Moure

 ![Brais Moure](Brais.png)

 Me dedico al desarrollo de software desde hace más de 12 años.  
 En 2018 comencé a divulgar contenido sobre programación en redes
 sociales como [@mouredev](https://moure.dev/), iniciando en 2022 esta
 actividad de resolución de retos de programación en comunidad.

 [moure.dev](https://moure.dev/) •
 [YouTube](https://youtube.com/mouredevapps) •
 [Twitter](https://twitter.com/mouredev)
 */
 