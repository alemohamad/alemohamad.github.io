import SwiftUI

class ColorSetViewModel: ObservableObject {
    @Published var colorName: String = ""
    @Published var isAdaptive: Bool = false
    @Published var lightColor: Color = .black
    @Published var darkColor: Color = .white
    
    typealias ColorSetValues = (
        red: String,
        green: String,
        blue: String,
        alpha: String
    )
    
    private func rgbValuesString(from color: Color) -> ColorSetValues {
        let uiColor = UIColor(color)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        return (
            String(format: "%.2f", red),
            String(format: "%.2f", green),
            String(format: "%.2f", blue),
            String(format: "%.2f", alpha)            
        )
    }
    
    func copyColorSetToClipboard() {
        UIPasteboard.general.string = "\(colorName).colorset"
    }
    
    func copyContentsToClipboard() {
        UIPasteboard.general.string = "Contents.json"
    }
    
    func copyColorToClipboard() {
        UIPasteboard.general.string = colorSetJSON(isAdaptive: isAdaptive)
    }
    
    private func colorSetJSON(isAdaptive: Bool = true) -> String {
        let lightColorSet = rgbValuesString(from: lightColor)
        var json = """
{
  "colors": [
    {
      "idiom": "universal",
      "color": {
        "color-space": "srgb",
        "components": {
          "red": "\(lightColorSet.red)",
          "green": "\(lightColorSet.green)",
          "blue": "\(lightColorSet.blue)",
          "alpha": "\(lightColorSet.alpha)"
        }
      }
    }
"""
        if isAdaptive {
            let darkColorSet = rgbValuesString(from: darkColor)
            json += """
,
    {
      "idiom": "universal",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "color": {
        "color-space": "srgb",
        "components": {
          "red": "\(darkColorSet.red)",
          "green": "\(darkColorSet.green)",
          "blue": "\(darkColorSet.blue)",
          "alpha": "\(darkColorSet.alpha)"
        }
      }
    }
"""
        }
        json += """

  ],
  "info": {
    "version": 1,
    "author": "xcode"
  }
}
"""
        return json
    }
}
