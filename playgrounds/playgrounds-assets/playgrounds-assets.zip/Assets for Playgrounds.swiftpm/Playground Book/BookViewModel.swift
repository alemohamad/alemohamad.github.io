import SwiftUI

class BookViewModel: ObservableObject {
    @Published var contentsGroup = false
    @Published var chaptersGroup = false
    @Published var chapterItem = false
    @Published var pagesGroup = false
    @Published var pageItem = false
    @Published var pageItemTemplate = false
    
    @Published var modulesGroup = false
    @Published var moduleItem = false
    @Published var moduleSourcesItem = false
    @Published var userModulesGroup = false
    @Published var userModuleItem = false
    @Published var userModuleSourcesItem = false
    
    @Published var htmlCutscene = false
    @Published var swiftCutscene = false
    
    func copyPlaygroundBookName() {
        UIPasteboard.general.string = "Book.playgroundbook"
    }
    
    func copyPlaygroundChapterName() {
        UIPasteboard.general.string = "Chapter.playgroundchapter"
    }
    
    func copyPlaygroundPageName() {
        UIPasteboard.general.string = "Page.playgroundpage"
    }
    
    func copyBookManifest() {
        let manifest = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Chapters</key>
    <array>
        <string>Chapter 1.playgroundchapter</string>
        <string>Chapter 2.playgroundchapter</string>
        <string>Chapter 3.playgroundchapter</string>
    </array>
    <key>ContentIdentifier</key>
    <string>com.apple.playgrounds.blank</string>
    <key>ContentVersion</key>
    <string>1.0</string>
    <key>DeploymentTarget</key>
    <string>ios-current</string>
    <key>DevelopmentRegion</key>
    <string>en</string>
    <key>SwiftVersion</key>
    <string>5.9</string>
    <key>Version</key>
    <string>8.0</string>
    <key>UserAutoImportedAuxiliaryModules</key>
    <array/>
    <key>UserModuleMode</key>
    <string>Full</string>
    <!-- Full, Limited or Disabled -->
    <key>HasMeaningfulResetPoint</key>
    <false/>
    <key>ImageReference</key>
    <string>playground-cover.png</string>
    <key>Subtitle</key>
    <string>Optional subtitle</string>
</dict>
</plist>
"""
        UIPasteboard.general.string = manifest
    }
    
    func copyChapterManifest() {
        let manifest = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Name</key>
    <string>My Playground</string>
    <!-- Chapter with template (has to be one chapter) -->
    <key>TemplatePageFilename</key>
    <string>Template.playgroundpage</string>
    <key>InitialUserPages</key>
    <array>
        <string>Page.playgroundpage</string>
        <string>Other Page.playgroundpage</string>
    </array>
    <!-- Chapter without template -->
    <key>Pages</key>
    <array>
        <string>Page.playgroundpage</string>
        <string>Other Page.playgroundpage</string>
    </array>
</dict>
</plist>
"""
        UIPasteboard.general.string = manifest
    }
    
    func copyPageManifest() {
        let manifest = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Name</key>
    <string>My Playground</string>
    <key>LiveViewEdgeToEdge</key>
    <false/>
    <key>LiveViewMode</key>
    <string>HiddenByDefault</string>
    <!-- HiddenByDefault, VisibleByDefault -->
</dict>
</plist>
"""
        UIPasteboard.general.string = manifest
    }
    
    func copyPageMain() {
        UIPasteboard.general.string = "// main.swift"
    }
    
    func copyPageLiveView() {
        UIPasteboard.general.string = "// LiveView.swift"
    }
    
    func copyHiddenModule() {
        let module = """
// Modules
// ModuleName.playgroundmodule
// Sources
"""
        UIPasteboard.general.string = module
    }
    
    func copySharedModule() {
        let module = """
// UserModules
// ModuleName.playgroundmodule
// Sources
"""
        UIPasteboard.general.string = module
    }
    
    func copyPrivateResources() {
        UIPasteboard.general.string = "PrivateResources"
    }
    
    func copyPublicResources() {
        UIPasteboard.general.string = "PublicResources"
    }
    
    func copyCutsceneSwiftManifest() {
        let manifest = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Name</key>
    <string>Cutscene Name</string>
</dict>
</plist>
"""
        UIPasteboard.general.string = manifest
    }
    
    func copyCutsceneHTMLManifest() {
        let manifest = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Name</key>
    <string>Cutscene Name</string>
    <key>CutsceneReference</key>
    <string>H5Square.html</string>
    <!-- PrivateResources folder -->
</dict>
</plist>
"""
        UIPasteboard.general.string = manifest
    }
    
    func copyHintsFile() {
        let hints = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Hints</key>
    <array>
        <dict>
            <key>Content</key>
            <string>Look at the `characters` property of `String`.</string>
        </dict>
        <dict>
            <key>Content</key>
            <string>This hint is initially hidden by a spoiler button.</string>
            <key>SpoilerButtonTitle</key>
            <string>Show Spoiler</string>
        </dict>
        <dict>
            <key>FileReference</key>
            <string>OutOfBandHint.txt</string>
        </dict>
        <dict>
            <key>FileReference</key>
            <string>OutOfBandHintWithSpoilerButton.txt</string>
            <key>SpoilerButtonTitle</key>
            <string>Show Spoiler</string>
        </dict>
    </array>
</dict>
</plist>
"""
        UIPasteboard.general.string = hints
    }
}
