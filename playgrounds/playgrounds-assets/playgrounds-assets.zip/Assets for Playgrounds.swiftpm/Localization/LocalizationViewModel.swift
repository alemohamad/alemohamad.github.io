import SwiftUI

class LocalizationViewModel: ObservableObject {
    @Published var pluralizationKey: String = ""
    @Published var pluralZero: String = ""
    @Published var pluralOne: String = ""
    @Published var pluralTwo: String = ""
    @Published var pluralFew: String = ""
    @Published var pluralMany: String = ""
    @Published var pluralOther: String = ""
    
    func copyDefaultToClipboard() {
        UIPasteboard.general.string = "defaultLocalization: \"en\","
    }
    
    func copyResourcesFolderToClipboard() {
        UIPasteboard.general.string = "Resources"
    }
    
    func copyLprojFolderToClipboard() {
        UIPasteboard.general.string = "en.lproj"
    }
    
    func copyStringsToClipboard() {
        UIPasteboard.general.string = "Localizable.strings"
    }
    
    func copyStringsExampleToClipboard() {
        UIPasteboard.general.string = """
"welcome_message" = "Welcome to our app!";
"completed_tasks" = "You have completed %d tasks.";
"meeting_schedule" = "Meeting with %@ on %@.";
"""
    }
    
    func copyStringsdictToClipboard() {
        UIPasteboard.general.string = "Localizable.stringsdict"
    }
    
    func copyPluralizedContentToClipboard() {
        UIPasteboard.general.string = pluralizedPlist()
    }
    
    private func pluralizedPlist() -> String {
        var plistContent = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>%lld \(pluralizationKey)</key>
    <dict>
        <key>NSStringLocalizedFormatKey</key>
        <string>%#@\(pluralizationKey)@</string>
        <key>\(pluralizationKey)</key>
        <dict>
            <key>NSStringFormatSpecTypeKey</key>
            <string>NSStringPluralRuleType</string>
            <key>NSStringFormatValueTypeKey</key>
            <string>d</string>
"""
        
        if !pluralZero.isEmpty {
            plistContent += """

            <key>zero</key>
            <string>\(pluralZero)</string>
"""
        }
        
        if !pluralOne.isEmpty {
            plistContent += """

            <key>one</key>
            <string>\(pluralOne)</string>
"""
        }
        
        if !pluralTwo.isEmpty {
            plistContent += """

            <key>two</key>
            <string>\(pluralTwo)</string>
"""
        }
        
        if !pluralFew.isEmpty {
            plistContent += """

            <key>few</key>
            <string>\(pluralFew)</string>
"""
        }
        
        if !pluralMany.isEmpty {
            plistContent += """

            <key>many</key>
            <string>\(pluralMany)</string>
"""
        }
        
        if !pluralOther.isEmpty {
            plistContent += """

            <key>other</key>
            <string>\(pluralOther)</string>
"""
        }
        
        let plistEnd = """

        </dict>
    </dict>
</dict>
</plist>
"""
        
        return plistContent + plistEnd
    }
}
