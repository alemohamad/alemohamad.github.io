import SwiftUI

struct ImageSetView: View {
    @ObservedObject var viewModel = ImageSetViewModel()
    
    var body: some View {
        Form {
            Section {
                TextField("Name this image",
                          text: $viewModel.imageName)
                .textInputAutocapitalization(.never)
                
                Toggle("Adaptive Image",
                       isOn: $viewModel.isAdaptive.animation())
            } header: {
                Text("Define an Image")
            } footer: {
                viewModel.footerAdaptive
            }
            
            Section {
                Picker("Choose image format", selection: $viewModel.imageType.animation()) {
                    ForEach(ImageSetViewModel.ImageOptions.allCases) { option in
                        Text(option.rawValue.uppercased())
                            .tag(option)
                    }
                }
            } footer: {
                viewModel.footerType
            }
            
            Section {
                Button {
                    viewModel.copyImageSetToClipboard()
                } label: {
                    if viewModel.imageName.isEmpty {
                        Label("Unnamed image",
                              systemImage: "folder.badge.plus")
                    } else {
                        Label("`\(viewModel.imageName).imageset`",
                              systemImage: "folder.badge.plus")
                    }
                }
                
                Button {
                    viewModel.copyContentsToClipboard()
                } label: {
                    Label("`Contents.json`",
                          systemImage: "doc.badge.plus")
                }
                
                Button {
                    viewModel.copyImageToClipboard()
                } label: {
                    Label("Copy ImageSet content",
                          systemImage: "ellipsis.curlybraces")
                }
                
                Label(viewModel.placeCopy,
                      systemImage: "doc.on.doc")
            } header: {
                Text("Add Image to the Project")
            } footer: {
                Text("Place the image set into the **Assets.xcassets** folder.")
            }
            .disabled(viewModel.imageName.isEmpty ? true : false)
        }
        .navigationBarTitle("New image set", displayMode: .inline)
    }
}

#Preview("ImageSet") {
    NavigationStack {
        ImageSetView()
    }
}
