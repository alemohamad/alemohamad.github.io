import SwiftUI

class ImageSetViewModel: ObservableObject {
    @Published var imageName: String = ""
    @Published var isAdaptive: Bool = false
    @Published var imageType: ImageOptions = .png
    
    enum ImageOptions: String, CaseIterable, Identifiable {
        case png
        case jpg
        case svg
        case pdf
        
        var id: String { self.rawValue }
    }
    
    var footerAdaptive: some View {
        if isAdaptive {
            return Text("For **dark mode** support, add a ‘-dark’ suffix to each counterpart file name for compatibility.\(adaptiveExample)")
        } else {
            return EmptyView()
        }
    }
    
    var adaptiveExample: String {
        if imageName.isEmpty {
            return ""
        } else {
            return "\n\nExample: \(imageName)-dark.\(imageType.rawValue)"
        }
    }
    
    var footerType: some View {
        if imageType == .png || imageType == .jpg {
            return Text("Selecting **\(imageType.rawValue.uppercased())** requires providing three sizes: include `@2x` and `@3x` in the filenames for retina displays.")
        } else {
            return EmptyView()
        }
    }
    
    var placeCopy: String {
        if imageType == .png || imageType == .jpg || isAdaptive {
            return "Place image files"
        } else {
            return "Place image file"
        }
    }
    
    func copyImageSetToClipboard() {
        UIPasteboard.general.string = "\(imageName).imageset"
    }
    
    func copyContentsToClipboard() {
        UIPasteboard.general.string = "Contents.json"
    }
    
    func copyImageToClipboard() {
        UIPasteboard.general.string = imageSetJSON()
    }
    
    private func imageSetJSON() -> String {
        let jsonBitmapDark = """
,
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "1x"
    },
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark@2x.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "2x"
    },
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark@3x.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "3x"
    }
"""
        
        let jsonBitmap = """
{
  "images" : [
    {
      "filename" : "\(imageName).\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "1x"
    },
    {
      "filename" : "\(imageName)@2x.\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "2x"
    },
    {
      "filename" : "\(imageName)@3x.\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "3x"
    }\(isAdaptive ? jsonBitmapDark : "")
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
"""
        
        let jsonVectorDark = """
,
    {
      "appearances" : [
        {
          "appearance" : "luminosity",
          "value" : "dark"
        }
      ],
      "filename" : "\(imageName)-dark.\(imageType.rawValue)",
      "idiom" : "universal"
    }
"""
        
        let jsonVector = """
{
  "images" : [
    {
      "filename" : "\(imageName).\(imageType.rawValue)",
      "idiom" : "universal"
    }\(isAdaptive ? jsonVectorDark : "")
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  },
  "properties" : {
    "preserves-vector-representation" : true
  }
}
"""

        switch imageType {
        case .png, .jpg:
            return jsonBitmap
        case .svg, .pdf:
            return jsonVector
        }
    }
}
