import SwiftUI

class ImageSetViewModel: ObservableObject {
    @Published var imageName: String = ""
    @Published var isAdaptive: Bool = false
    @Published var imageType: ImageOptions = .png
    
    enum ImageOptions: String, CaseIterable, Identifiable {
        case png
        case jpg
        case svg
        case pdf
        case symbol
        case appicon
        
        var id: String { self.rawValue }
        
        var folderExtension: String {
            switch self {
            case .symbol:
                return "symbolset"
            case .appicon:
                return "appiconset"
            default:
                return "imageset"
            }
        }
    }
    
    var footerAdaptive: some View {
        if isAdaptive && imageType != .symbol && imageType != .appicon {
            return Text("For **dark mode** support, add a ‘-dark’ suffix to each counterpart file name for compatibility.\(adaptiveExample)")
        } else {
            return EmptyView()
        }
    }
    
    var adaptiveExample: String {
        if imageName.isEmpty {
            return ""
        } else {
            return "\n\nExample: \(imageName)-dark.\(imageType.rawValue)"
        }
    }
    
    var footerType: some View {
        if imageType == .png || imageType == .jpg {
            return Text("Selecting **\(imageType.rawValue.uppercased())** requires providing three sizes: include `@2x` and `@3x` in the filenames for retina displays.")
        } else if imageType == .appicon {
            return Text("Name the app icon `‘AppIcon’` to ensure it’s recognized as the main app icon. Also remember that it has to be 1024x1024.")
        } else if imageType == .symbol {
            return Text("If you are working with custom symbols, I recommend you watch the **WWDC21** session `‘Create custom symbols‘`.")
        } else {
            return EmptyView()
        }
    }
    
    var placeCopy: String {
        if imageType == .png || imageType == .jpg || isAdaptive {
            return "Place image files"
        } else {
            return "Place image file"
        }
    }
    
    func copyImageSetToClipboard() {
        UIPasteboard.general.string = "\(imageName).\(imageType.folderExtension)"
    }
    
    func copyContentsToClipboard() {
        UIPasteboard.general.string = "Contents.json"
    }
    
    func copyImageToClipboard() {
        UIPasteboard.general.string = imageSetJSON()
    }
    
    private func imageSetJSON() -> String {
        let jsonBitmapDark = """
,
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "1x"
    },
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark@2x.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "2x"
    },
    {
      "idiom": "universal",
      "filename": "\(imageName)-dark@3x.\(imageType.rawValue)",
      "appearances": [
        {
          "appearance": "luminosity",
          "value": "dark"
        }
      ],
      "scale": "3x"
    }
"""
        
        let jsonBitmap = """
{
  "images" : [
    {
      "filename" : "\(imageName).\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "1x"
    },
    {
      "filename" : "\(imageName)@2x.\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "2x"
    },
    {
      "filename" : "\(imageName)@3x.\(imageType.rawValue)",
      "idiom" : "universal",
      "scale" : "3x"
    }\(isAdaptive ? jsonBitmapDark : "")
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
"""
        
        let jsonVectorDark = """
,
    {
      "appearances" : [
        {
          "appearance" : "luminosity",
          "value" : "dark"
        }
      ],
      "filename" : "\(imageName)-dark.\(imageType.rawValue)",
      "idiom" : "universal"
    }
"""
        
        let jsonVector = """
{
  "images" : [
    {
      "filename" : "\(imageName).\(imageType.rawValue)",
      "idiom" : "universal"
    }\(isAdaptive ? jsonVectorDark : "")
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  },
  "properties" : {
    "preserves-vector-representation" : true
  }
}
"""
        
        let jsonSymbol = """
{
  "symbols" : [
    {
      "filename" : "\(imageName).svg",
      "idiom" : "universal"
    }
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
"""
        
        let jsonAppicon = """
{
  "images" : [
    {
      "filename" : "\(imageName).png",
      "idiom" : "universal",
      "platform" : "ios",
      "size" : "1024x1024"
    }
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
"""
        
        switch imageType {
        case .png, .jpg:
            return jsonBitmap
        case .svg, .pdf:
            return jsonVector
        case .symbol:
            return jsonSymbol
        case .appicon:
            return jsonAppicon
        }
    }
}
