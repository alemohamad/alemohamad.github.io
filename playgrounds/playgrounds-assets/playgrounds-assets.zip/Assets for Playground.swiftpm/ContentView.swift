import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: StructureView()) {
                    MenuItemView(text: "Project structure",
                                 icon: "folder.fill",
                                 color: .red)
                }
                
                NavigationLink(destination: ColorSetView()) {
                    MenuItemView(text: "Add color",
                                 icon: "swatchpalette.fill",
                                 color: .green)
                }
                
                NavigationLink(destination: ImageSetView()) {
                    MenuItemView(text: "Add image",
                                 icon: "photo.on.rectangle.angled",
                                 color: .blue)
                }
                
                NavigationLink(destination: CustomFontsView()) { 
                    MenuItemView(text: "Use custom fonts",
                                 icon: "textformat",
                                 color: .purple)
                }
            }
            .navigationBarTitle("Assets")
        }
        .listStyle(.sidebar)
    }
}

#Preview("Assets List View") {
    ContentView()
        .preferredColorScheme(.none)
}

struct MenuItemView: View {
    let text: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack {
            IconView(icon: icon,
                     color: color)
            Text(text)
        }
    }
}

struct IconView: View {
    let icon: String
    let color: Color
    
    var body: some View {
        RoundedRectangle(cornerRadius: 8)
            .fill(color)
            .frame(width: 40, height: 40)
            .overlay(
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundStyle(.white)
            )
            .padding(.trailing, 8)
    }
}
