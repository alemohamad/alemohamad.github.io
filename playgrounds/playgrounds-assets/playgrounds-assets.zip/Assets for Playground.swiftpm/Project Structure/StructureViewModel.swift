import SwiftUI

class StructureViewModel: ObservableObject {
    func copyAssetsToClipboard() {
        UIPasteboard.general.string = "Assets.xcassets"
    }
    
    func copyContentsToClipboard() {
        UIPasteboard.general.string = "Contents.json"
    }
    
    func copyJSONToClipboard() {
        UIPasteboard.general.string = basicJSON()
    }
    
    private func basicJSON() -> String {
        return """
{
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
"""
    }
}
